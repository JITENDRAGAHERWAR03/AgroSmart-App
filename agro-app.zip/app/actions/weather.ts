"use server"

interface WeatherResponse {
  current: {
    location: string
    temperature: number
    condition: string
    humidity: number
    windSpeed: number
    windDirection: string
    pressure: number
    visibility: number
    uvIndex: number
    feelsLike: number
  }
  forecast: Array<{
    day: string
    date: string
    high: number
    low: number
    condition: string
    precipitation: number
    icon: string
  }>
  alerts: Array<{
    type: string
    title: string
    description: string
    priority: string
  }>
  agricultural: {
    soilMoisture: string
    growingDegreeDay: number
    evapotranspiration: number
    frostRisk: string
    sprayConditions: string
    harvestConditions: string
  }
}

const getWindDirection = (degrees: number): string => {
  const directions = [
    "N",
    "NNE",
    "NE",
    "ENE",
    "E",
    "ESE",
    "SE",
    "SSE",
    "S",
    "SSW",
    "SW",
    "WSW",
    "W",
    "WNW",
    "NW",
    "NNW",
  ]
  return directions[Math.round(degrees / 22.5) % 16]
}

const getDemoWeatherData = (location: string): WeatherResponse => ({
  current: {
    location: `${location} (Demo)`,
    temperature: 22,
    condition: "Partly Cloudy",
    humidity: 68,
    windSpeed: 12,
    windDirection: "NW",
    pressure: 1013,
    visibility: 10,
    uvIndex: 6,
    feelsLike: 24,
  },
  forecast: [
    {
      day: "Today",
      date: "Mar 15",
      high: 25,
      low: 18,
      condition: "Partly Cloudy",
      precipitation: 10,
      icon: "partly-cloudy",
    },
    {
      day: "Tomorrow",
      date: "Mar 16",
      high: 28,
      low: 20,
      condition: "Sunny",
      precipitation: 0,
      icon: "sunny",
    },
    {
      day: "Wednesday",
      date: "Mar 17",
      high: 23,
      low: 16,
      condition: "Light Rain",
      precipitation: 80,
      icon: "rain",
    },
    {
      day: "Thursday",
      date: "Mar 18",
      high: 21,
      low: 14,
      condition: "Cloudy",
      precipitation: 30,
      icon: "cloudy",
    },
    {
      day: "Friday",
      date: "Mar 19",
      high: 26,
      low: 19,
      condition: "Partly Cloudy",
      precipitation: 15,
      icon: "partly-cloudy",
    },
  ],
  alerts: [
    {
      type: "info",
      title: "Demo Mode",
      description: "Using demo weather data. Add OPENWEATHER_API_KEY to environment variables for live data.",
      priority: "medium",
    },
  ],
  agricultural: {
    soilMoisture: "Adequate",
    growingDegreeDay: 145,
    evapotranspiration: 4.2,
    frostRisk: "Low",
    sprayConditions: "Good",
    harvestConditions: "Fair",
  },
})

export async function fetchWeatherData(locationQuery: string): Promise<WeatherResponse> {
  try {
    // Get API key from server environment (secure)
    const API_KEY = process.env.OPENWEATHER_API_KEY

    if (!API_KEY) {
      console.log("[v0] No OpenWeather API key found, using demo data")
      return getDemoWeatherData(locationQuery)
    }

    // Get coordinates first
    const geoResponse = await fetch(
      `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(locationQuery)}&limit=1&appid=${API_KEY}`,
    )

    if (!geoResponse.ok) {
      throw new Error("Location not found")
    }

    const geoData = await geoResponse.json()
    if (geoData.length === 0) {
      throw new Error("Location not found")
    }

    const { lat, lon, name, country } = geoData[0]

    // Get current weather
    const currentResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`,
    )

    // Get forecast
    const forecastResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`,
    )

    if (!currentResponse.ok || !forecastResponse.ok) {
      throw new Error("Failed to fetch weather data")
    }

    const currentData = await currentResponse.json()
    const forecastData = await forecastResponse.json()

    // Process forecast data (get daily forecasts)
    const dailyForecasts = []
    const processedDates = new Set()

    for (const item of forecastData.list.slice(0, 40)) {
      const date = new Date(item.dt * 1000)
      const dateStr = date.toDateString()

      if (!processedDates.has(dateStr) && dailyForecasts.length < 5) {
        processedDates.add(dateStr)
        dailyForecasts.push({
          day:
            dailyForecasts.length === 0
              ? "Today"
              : dailyForecasts.length === 1
                ? "Tomorrow"
                : date.toLocaleDateString("en-US", { weekday: "long" }),
          date: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
          high: Math.round(item.main.temp_max),
          low: Math.round(item.main.temp_min),
          condition: item.weather[0].main,
          precipitation: Math.round((item.pop || 0) * 100),
          icon: item.weather[0].main.toLowerCase(),
        })
      }
    }

    // Calculate agricultural data based on weather
    const temp = currentData.main.temp
    const humidity = currentData.main.humidity
    const windSpeed = currentData.wind.speed * 3.6 // Convert m/s to km/h

    const agricultural = {
      soilMoisture: humidity > 70 ? "High" : humidity > 50 ? "Adequate" : "Low",
      growingDegreeDay: Math.max(0, Math.round(((temp + (temp - 5)) / 2) * 30)), // Simplified GDD calculation
      evapotranspiration: Math.round((temp * 0.2 + windSpeed * 0.1) * 10) / 10,
      frostRisk: temp < 5 ? "High" : temp < 10 ? "Medium" : "Low",
      sprayConditions: windSpeed < 15 && humidity < 80 ? "Good" : windSpeed < 25 ? "Fair" : "Poor",
      harvestConditions: humidity < 60 && windSpeed < 20 ? "Good" : "Fair",
    }

    // Generate alerts based on conditions
    const alerts = []
    if (dailyForecasts.some((day) => day.precipitation > 70)) {
      alerts.push({
        type: "warning",
        title: "Heavy Rain Expected",
        description: "Significant rainfall expected. Consider delaying field operations.",
        priority: "high",
      })
    }
    if (temp > 15 && temp < 25 && humidity > 40) {
      alerts.push({
        type: "info",
        title: "Optimal Planting Conditions",
        description: "Current conditions are ideal for spring planting.",
        priority: "medium",
      })
    }

    const processedWeatherData: WeatherResponse = {
      current: {
        location: `${name}, ${country}`,
        temperature: Math.round(currentData.main.temp),
        condition: currentData.weather[0].main,
        humidity: currentData.main.humidity,
        windSpeed: Math.round(windSpeed),
        windDirection: getWindDirection(currentData.wind.deg),
        pressure: currentData.main.pressure,
        visibility: Math.round((currentData.visibility || 10000) / 1000),
        uvIndex: 6, // UV data requires separate API call
        feelsLike: Math.round(currentData.main.feels_like),
      },
      forecast: dailyForecasts,
      alerts,
      agricultural,
    }

    return processedWeatherData
  } catch (err) {
    console.error("Weather fetch error:", err)
    // Fallback to demo data
    return getDemoWeatherData(locationQuery)
  }
}
