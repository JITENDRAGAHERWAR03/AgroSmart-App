"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Beaker,
  Calculator,
  Calendar,
  Droplets,
  Leaf,
  Zap,
  AlertTriangle,
  CheckCircle,
  Info,
  Clock,
  Target,
} from "lucide-react"

const fertilizerTypes = [
  {
    id: "organic",
    name: "Organic Fertilizers",
    description: "Natural, slow-release nutrients",
    examples: ["Compost", "Manure", "Bone Meal", "Fish Emulsion"],
  },
  {
    id: "synthetic",
    name: "Synthetic Fertilizers",
    description: "Quick-acting, precise nutrient control",
    examples: ["NPK Blends", "Urea", "Ammonium Sulfate", "Triple Superphosphate"],
  },
  {
    id: "liquid",
    name: "Liquid Fertilizers",
    description: "Fast absorption, easy application",
    examples: ["Liquid NPK", "Foliar Feeds", "Hydroponic Solutions"],
  },
  {
    id: "granular",
    name: "Granular Fertilizers",
    description: "Long-lasting, controlled release",
    examples: ["Slow-Release NPK", "Granular Organics", "Coated Urea"],
  },
]

const mockSoilData = {
  ph: 6.8,
  nitrogen: 45, // Low
  phosphorus: 32, // Medium
  potassium: 28, // Low
  organicMatter: 3.2,
  cec: 15.2, // Cation Exchange Capacity
}

const mockRecommendations = [
  {
    id: 1,
    name: "Balanced NPK 10-10-10",
    type: "synthetic",
    priority: "high",
    npk: { n: 10, p: 10, k: 10 },
    applicationRate: "150-200 kg/hectare",
    timing: "Pre-planting",
    cost: "$45/50kg bag",
    benefits: ["Balanced nutrition", "Quick availability", "Easy application"],
    suitableFor: ["Corn", "Tomatoes", "General crops"],
    applicationMethod: "Broadcast and incorporate",
  },
  {
    id: 2,
    name: "Potassium Sulfate",
    type: "synthetic",
    priority: "high",
    npk: { n: 0, p: 0, k: 50 },
    applicationRate: "100-150 kg/hectare",
    timing: "Mid-season",
    cost: "$65/50kg bag",
    benefits: ["High potassium", "Sulfur bonus", "Chloride-free"],
    suitableFor: ["Fruits", "Vegetables", "Quality crops"],
    applicationMethod: "Side-dress or foliar spray",
  },
  {
    id: 3,
    name: "Organic Compost",
    type: "organic",
    priority: "medium",
    npk: { n: 2, p: 1, k: 2 },
    applicationRate: "2-4 tons/hectare",
    timing: "Fall or early spring",
    cost: "$25/ton",
    benefits: ["Soil structure", "Slow release", "Microbial activity"],
    suitableFor: ["All crops", "Soil building"],
    applicationMethod: "Broadcast and till in",
  },
  {
    id: 4,
    name: "Liquid Nitrogen 28-0-0",
    type: "liquid",
    priority: "medium",
    npk: { n: 28, p: 0, k: 0 },
    applicationRate: "100-150 L/hectare",
    timing: "Side-dress application",
    cost: "$1.20/L",
    benefits: ["Quick nitrogen", "Precise application", "No dust"],
    suitableFor: ["Corn", "Wheat", "Leafy greens"],
    applicationMethod: "Inject or surface apply",
  },
]

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "high":
      return "bg-red-100 text-red-800"
    case "medium":
      return "bg-yellow-100 text-yellow-800"
    case "low":
      return "bg-green-100 text-green-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

const getNutrientLevel = (value: number, nutrient: string) => {
  const thresholds = {
    nitrogen: { low: 40, medium: 60 },
    phosphorus: { low: 30, medium: 50 },
    potassium: { low: 30, medium: 50 },
  }

  const threshold = thresholds[nutrient as keyof typeof thresholds]
  if (value < threshold.low) return { level: "Low", color: "text-red-600" }
  if (value < threshold.medium) return { level: "Medium", color: "text-yellow-600" }
  return { level: "High", color: "text-green-600" }
}

export default function FertilizerPage() {
  const [activeTab, setActiveTab] = useState("advisor")
  const [cropType, setCropType] = useState("")
  const [fieldSize, setFieldSize] = useState("")
  const [growthStage, setGrowthStage] = useState("")
  const [showRecommendations, setShowRecommendations] = useState(false)
  const [selectedFertilizer, setSelectedFertilizer] = useState<(typeof mockRecommendations)[0] | null>(null)
  const [calculatorData, setCalculatorData] = useState({
    fieldSizeCalc: "",
    targetYield: "",
    nRatio: "",
    pRatio: "",
    kRatio: "",
  })
  const [calculationResults, setCalculationResults] = useState<{
    totalFertilizer: number
    numberOfBags: number
    estimatedCost: number
    costPerHectare: number
  } | null>(null)

  const handleGetRecommendations = () => {
    if (!cropType || !fieldSize || !growthStage) {
      alert("Please fill in all crop information fields")
      return
    }
    setShowRecommendations(true)
  }

  const calculateFertilizer = () => {
    const { fieldSizeCalc, targetYield, nRatio, pRatio, kRatio } = calculatorData

    if (!fieldSizeCalc || !targetYield || !nRatio || !pRatio || !kRatio) {
      alert("Please fill in all calculator fields")
      return
    }

    const fieldSizeNum = Number.parseFloat(fieldSizeCalc)
    const targetYieldNum = Number.parseFloat(targetYield)
    const nRatioNum = Number.parseFloat(nRatio)
    const pRatioNum = Number.parseFloat(pRatio)
    const kRatioNum = Number.parseFloat(kRatio)

    const totalNPK = nRatioNum + pRatioNum + kRatioNum
    const fertilizerPerHectare = targetYieldNum * 50 // Base calculation
    const totalFertilizer = fertilizerPerHectare * fieldSizeNum
    const numberOfBags = Math.ceil(totalFertilizer / 50) // 50kg bags
    const costPerBag = 45 // Average cost per bag
    const estimatedCost = numberOfBags * costPerBag
    const costPerHectare = estimatedCost / fieldSizeNum

    setCalculationResults({
      totalFertilizer: Math.round(totalFertilizer),
      numberOfBags,
      estimatedCost: Math.round(estimatedCost),
      costPerHectare: Math.round(costPerHectare),
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Fertilizer Advisor</h1>
        <p className="text-muted-foreground text-lg">
          Personalized fertilizer recommendations based on soil analysis and crop requirements
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="advisor">Get Advice</TabsTrigger>
          <TabsTrigger value="calculator">Calculator</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="guide">Guide</TabsTrigger>
        </TabsList>

        <TabsContent value="advisor" className="space-y-6">
          {/* Current Soil Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Beaker className="h-5 w-5" />
                <span>Current Soil Nutrient Status</span>
              </CardTitle>
              <CardDescription>Based on your latest soil test results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-2">
                      <Leaf className="h-4 w-4 text-green-600" />
                      <span>Nitrogen (N)</span>
                    </span>
                    <Badge className={getNutrientLevel(mockSoilData.nitrogen, "nitrogen").color}>
                      {getNutrientLevel(mockSoilData.nitrogen, "nitrogen").level}
                    </Badge>
                  </div>
                  <Progress value={mockSoilData.nitrogen} className="h-2" />
                  <p className="text-sm text-muted-foreground">{mockSoilData.nitrogen}% available</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-2">
                      <Zap className="h-4 w-4 text-orange-600" />
                      <span>Phosphorus (P)</span>
                    </span>
                    <Badge className={getNutrientLevel(mockSoilData.phosphorus, "phosphorus").color}>
                      {getNutrientLevel(mockSoilData.phosphorus, "phosphorus").level}
                    </Badge>
                  </div>
                  <Progress value={mockSoilData.phosphorus} className="h-2" />
                  <p className="text-sm text-muted-foreground">{mockSoilData.phosphorus}% available</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center space-x-2">
                      <Droplets className="h-4 w-4 text-purple-600" />
                      <span>Potassium (K)</span>
                    </span>
                    <Badge className={getNutrientLevel(mockSoilData.potassium, "potassium").color}>
                      {getNutrientLevel(mockSoilData.potassium, "potassium").level}
                    </Badge>
                  </div>
                  <Progress value={mockSoilData.potassium} className="h-2" />
                  <p className="text-sm text-muted-foreground">{mockSoilData.potassium}% available</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Crop Information Input */}
          <Card>
            <CardHeader>
              <CardTitle>Crop Information</CardTitle>
              <CardDescription>Tell us about your crop to get personalized recommendations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="crop">Crop Type</Label>
                  <Select value={cropType} onValueChange={setCropType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select crop" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="corn">Corn</SelectItem>
                      <SelectItem value="tomatoes">Tomatoes</SelectItem>
                      <SelectItem value="wheat">Wheat</SelectItem>
                      <SelectItem value="soybeans">Soybeans</SelectItem>
                      <SelectItem value="carrots">Carrots</SelectItem>
                      <SelectItem value="apples">Apples</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="field-size">Field Size (hectares)</Label>
                  <Input
                    id="field-size"
                    placeholder="Enter field size"
                    value={fieldSize}
                    onChange={(e) => setFieldSize(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="growth-stage">Growth Stage</Label>
                  <Select value={growthStage} onValueChange={setGrowthStage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pre-plant">Pre-planting</SelectItem>
                      <SelectItem value="seedling">Seedling</SelectItem>
                      <SelectItem value="vegetative">Vegetative</SelectItem>
                      <SelectItem value="flowering">Flowering</SelectItem>
                      <SelectItem value="fruiting">Fruiting</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={handleGetRecommendations} className="w-full" size="lg">
                <Target className="h-5 w-5 mr-2" />
                Get Fertilizer Recommendations
              </Button>
            </CardContent>
          </Card>

          {/* Recommendations */}
          {showRecommendations && (
            <div className="space-y-6">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Based on your soil analysis and {cropType} crop selection for {fieldSize} hectares at {growthStage}{" "}
                  stage, here are our personalized fertilizer recommendations:
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {mockRecommendations.map((rec) => (
                  <Card
                    key={rec.id}
                    className="cursor-pointer hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/20"
                    onClick={() => setSelectedFertilizer(rec)}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{rec.name}</CardTitle>
                        <Badge className={getPriorityColor(rec.priority)}>{rec.priority} Priority</Badge>
                      </div>
                      <CardDescription>
                        NPK: {rec.npk.n}-{rec.npk.p}-{rec.npk.k}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Application Rate:</span>
                          <span className="font-medium">{rec.applicationRate}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Timing:</span>
                          <span className="font-medium">{rec.timing}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Cost:</span>
                          <span className="font-medium">{rec.cost}</span>
                        </div>
                        <div className="pt-2">
                          <p className="text-sm text-muted-foreground">Best for: {rec.suitableFor.join(", ")}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="calculator" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calculator className="h-5 w-5" />
                <span>Fertilizer Calculator</span>
              </CardTitle>
              <CardDescription>Calculate exact fertilizer amounts for your field</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Field Information</h4>
                  <div className="space-y-3">
                    <div>
                      <Label>Field Size (hectares)</Label>
                      <Input
                        placeholder="10"
                        value={calculatorData.fieldSizeCalc}
                        onChange={(e) => setCalculatorData((prev) => ({ ...prev, fieldSizeCalc: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label>Target Yield (tons/hectare)</Label>
                      <Input
                        placeholder="8"
                        value={calculatorData.targetYield}
                        onChange={(e) => setCalculatorData((prev) => ({ ...prev, targetYield: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label>Fertilizer NPK Ratio</Label>
                      <div className="grid grid-cols-3 gap-2">
                        <Input
                          placeholder="N"
                          value={calculatorData.nRatio}
                          onChange={(e) => setCalculatorData((prev) => ({ ...prev, nRatio: e.target.value }))}
                        />
                        <Input
                          placeholder="P"
                          value={calculatorData.pRatio}
                          onChange={(e) => setCalculatorData((prev) => ({ ...prev, pRatio: e.target.value }))}
                        />
                        <Input
                          placeholder="K"
                          value={calculatorData.kRatio}
                          onChange={(e) => setCalculatorData((prev) => ({ ...prev, kRatio: e.target.value }))}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">Calculated Requirements</h4>
                  <div className="space-y-3 p-4 bg-muted/30 rounded-lg">
                    {calculationResults ? (
                      <>
                        <div className="flex justify-between">
                          <span>Total Fertilizer Needed:</span>
                          <span className="font-semibold">{calculationResults.totalFertilizer} kg</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Number of Bags (50kg):</span>
                          <span className="font-semibold">{calculationResults.numberOfBags} bags</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Estimated Cost:</span>
                          <span className="font-semibold">${calculationResults.estimatedCost}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Cost per Hectare:</span>
                          <span className="font-semibold">${calculationResults.costPerHectare}</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between">
                          <span>Total Fertilizer Needed:</span>
                          <span className="font-semibold">-- kg</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Number of Bags (50kg):</span>
                          <span className="font-semibold">-- bags</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Estimated Cost:</span>
                          <span className="font-semibold">$--</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Cost per Hectare:</span>
                          <span className="font-semibold">$--</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <Button className="w-full" onClick={calculateFertilizer}>
                <Calculator className="h-4 w-4 mr-2" />
                Calculate Requirements
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Application Rate Guide</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Light Application</h4>
                  <p className="text-2xl font-bold text-green-600 mb-1">50-100 kg/ha</p>
                  <p className="text-sm text-muted-foreground">Maintenance fertilization for established crops</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Medium Application</h4>
                  <p className="text-2xl font-bold text-yellow-600 mb-1">100-200 kg/ha</p>
                  <p className="text-sm text-muted-foreground">Standard application for most crops</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Heavy Application</h4>
                  <p className="text-2xl font-bold text-red-600 mb-1">200-300 kg/ha</p>
                  <p className="text-sm text-muted-foreground">High-demand crops or deficient soils</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Fertilizer Application Schedule</span>
              </CardTitle>
              <CardDescription>Optimal timing for fertilizer applications throughout the season</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="h-4 w-4 text-blue-600" />
                      <h4 className="font-semibold">Pre-Plant</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">2-4 weeks before planting</p>
                    <ul className="text-sm space-y-1">
                      <li>• Base NPK application</li>
                      <li>• Organic matter incorporation</li>
                      <li>• Soil pH adjustment</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="h-4 w-4 text-green-600" />
                      <h4 className="font-semibold">At Planting</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">During seeding/transplanting</p>
                    <ul className="text-sm space-y-1">
                      <li>• Starter fertilizer</li>
                      <li>• Phosphorus placement</li>
                      <li>• Micronutrient application</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="h-4 w-4 text-yellow-600" />
                      <h4 className="font-semibold">Side-Dress</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">4-6 weeks after planting</p>
                    <ul className="text-sm space-y-1">
                      <li>• Nitrogen top-dress</li>
                      <li>• Growth stage nutrition</li>
                      <li>• Foliar applications</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-purple-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="h-4 w-4 text-purple-600" />
                      <h4 className="font-semibold">Reproductive</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">During flowering/fruiting</p>
                    <ul className="text-sm space-y-1">
                      <li>• Potassium boost</li>
                      <li>• Calcium applications</li>
                      <li>• Quality nutrients</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Seasonal Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { month: "March", tasks: ["Soil testing", "Pre-plant fertilizer", "Organic matter"] },
                  { month: "April", tasks: ["Starter fertilizer", "Planting nutrition", "Micronutrients"] },
                  { month: "May", tasks: ["First side-dress", "Nitrogen application", "Growth monitoring"] },
                  { month: "June", tasks: ["Second side-dress", "Foliar feeding", "Pest management"] },
                ].map((item, index) => (
                  <div key={index} className="flex items-center space-x-4 p-3 border rounded-lg">
                    <div className="w-20 text-center">
                      <div className="font-semibold">{item.month}</div>
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-wrap gap-2">
                        {item.tasks.map((task, taskIndex) => (
                          <Badge key={taskIndex} variant="outline">
                            {task}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guide" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Fertilizer Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {fertilizerTypes.map((type) => (
                    <div key={type.id} className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">{type.name}</h4>
                      <p className="text-sm text-muted-foreground mb-3">{type.description}</p>
                      <div className="flex flex-wrap gap-1">
                        {type.examples.map((example, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {example}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Best Practices</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-medium">Soil Test First</p>
                      <p className="text-sm text-muted-foreground">
                        Always conduct soil tests before fertilizer application
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-medium">Right Rate, Right Time</p>
                      <p className="text-sm text-muted-foreground">Apply correct amounts at optimal growth stages</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-medium">Weather Considerations</p>
                      <p className="text-sm text-muted-foreground">
                        Avoid application before heavy rain or extreme weather
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                    <div>
                      <p className="font-medium">Avoid Over-Application</p>
                      <p className="text-sm text-muted-foreground">Excess fertilizer can harm crops and environment</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Nutrient Deficiency Signs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center">
                    <Leaf className="h-4 w-4 text-green-600 mr-2" />
                    Nitrogen Deficiency
                  </h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Yellowing of older leaves</li>
                    <li>• Stunted growth</li>
                    <li>• Reduced leaf size</li>
                    <li>• Poor overall vigor</li>
                  </ul>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center">
                    <Zap className="h-4 w-4 text-orange-600 mr-2" />
                    Phosphorus Deficiency
                  </h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Purple leaf coloration</li>
                    <li>• Delayed maturity</li>
                    <li>• Poor root development</li>
                    <li>• Reduced flowering</li>
                  </ul>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center">
                    <Droplets className="h-4 w-4 text-purple-600 mr-2" />
                    Potassium Deficiency
                  </h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Leaf edge burning</li>
                    <li>• Weak stems</li>
                    <li>• Poor disease resistance</li>
                    <li>• Reduced fruit quality</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Fertilizer Detail Modal */}
      {selectedFertilizer && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl">{selectedFertilizer.name}</CardTitle>
                <Button variant="ghost" onClick={() => setSelectedFertilizer(null)}>
                  ×
                </Button>
              </div>
              <CardDescription>
                NPK: {selectedFertilizer.npk.n}-{selectedFertilizer.npk.p}-{selectedFertilizer.npk.k} •{" "}
                {selectedFertilizer.type}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Application Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Rate:</span>
                      <span>{selectedFertilizer.applicationRate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Timing:</span>
                      <span>{selectedFertilizer.timing}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Method:</span>
                      <span>{selectedFertilizer.applicationMethod}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Cost:</span>
                      <span>{selectedFertilizer.cost}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Benefits</h4>
                  <ul className="text-sm space-y-1">
                    {selectedFertilizer.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Suitable Crops</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedFertilizer.suitableFor.map((crop, index) => (
                    <Badge key={index} variant="outline">
                      {crop}
                    </Badge>
                  ))}
                </div>
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Application Method:</strong> {selectedFertilizer.applicationMethod}
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
