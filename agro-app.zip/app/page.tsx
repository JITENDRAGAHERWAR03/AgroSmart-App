import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Cloud, Sprout, Beaker, ShoppingCart, TrendingUp, ArrowRight, Users, Award, Globe } from "lucide-react"
import Link from "next/link"

const features = [
  {
    icon: Sprout,
    title: "Soil Detection",
    description: "Advanced soil analysis and health monitoring for optimal crop growth",
    href: "/soil",
    color: "text-green-600",
  },
  {
    icon: Cloud,
    title: "Weather Knowledge",
    description: "Real-time weather data and forecasts tailored for agriculture",
    href: "/weather",
    color: "text-blue-600",
  },
  {
    icon: Leaf,
    title: "Crop Information",
    description: "Comprehensive database of crop varieties, growing tips, and best practices",
    href: "/crops",
    color: "text-emerald-600",
  },
  {
    icon: Beaker,
    title: "Fertilizer Advisor",
    description: "Personalized fertilizer recommendations based on soil and crop analysis",
    href: "/fertilizer",
    color: "text-orange-600",
  },
  {
    icon: ShoppingCart,
    title: "Online Store",
    description: "Quality agricultural products, seeds, tools, and equipment",
    href: "/store",
    color: "text-purple-600",
  },
  {
    icon: TrendingUp,
    title: "Market Information",
    description: "Live market prices, trends, and trading opportunities",
    href: "/market",
    color: "text-red-600",
  },
]

const stats = [
  { icon: Users, label: "Active Farmers", value: "50K+" },
  { icon: Globe, label: "Countries Served", value: "25+" },
  { icon: Award, label: "Success Rate", value: "95%" },
  { icon: Leaf, label: "Crops Analyzed", value: "200+" },
]

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 px-4 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4">
            Modern Agriculture Platform
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">
            Grow Smarter with <span className="text-primary">Agro</span>
          </h1>
          <p className="text-xl text-muted-foreground text-balance mb-8 max-w-2xl mx-auto">
            Comprehensive agriculture platform combining soil detection, weather insights, crop knowledge, and market
            intelligence to maximize your farming success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8">
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 bg-transparent">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="h-8 w-8 text-primary mx-auto mb-2" />
                <div className="text-3xl font-bold text-primary mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Everything You Need for Modern Farming</h2>
            <p className="text-xl text-muted-foreground text-balance max-w-2xl mx-auto">
              Our comprehensive platform provides all the tools and insights you need to make data-driven decisions and
              optimize your agricultural operations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/20"
              >
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <feature.icon className={`h-6 w-6 ${feature.color}`} />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base mb-4">{feature.description}</CardDescription>
                  <Link href={feature.href}>
                    <Button variant="ghost" className="group-hover:text-primary p-0 h-auto">
                      Learn More
                      <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Transform Your Farming?</h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto text-balance">
            Join thousands of farmers who are already using Agro to increase yields, reduce costs, and make smarter
            agricultural decisions.
          </p>
          <Button size="lg" variant="secondary" className="text-lg px-8">
            Start Your Journey
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  )
}
