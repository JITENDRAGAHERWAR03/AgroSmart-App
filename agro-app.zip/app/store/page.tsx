"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Filter,
  ShoppingCart,
  Star,
  Package,
  Truck,
  Shield,
  Heart,
  Plus,
  Minus,
  Sprout,
  Wrench,
  Beaker,
  Scissors,
} from "lucide-react"

const categories = [
  { id: "all", name: "All Products", count: 156 },
  { id: "seeds", name: "Seeds & Plants", count: 45 },
  { id: "fertilizers", name: "Fertilizers", count: 32 },
  { id: "tools", name: "Tools & Equipment", count: 28 },
  { id: "pesticides", name: "Pesticides", count: 24 },
  { id: "irrigation", name: "Irrigation", count: 27 },
]

const mockProducts = [
  {
    id: 1,
    name: "Premium Corn Seeds - Hybrid Variety",
    category: "seeds",
    price: 45.99,
    originalPrice: 52.99,
    rating: 4.8,
    reviews: 124,
    image: "/corn-seeds-package.jpg",
    inStock: true,
    stockCount: 50,
    description: "High-yield hybrid corn seeds with excellent disease resistance",
    features: ["Disease resistant", "High yield", "90-day maturity", "Drought tolerant"],
    seller: "AgriSeeds Pro",
    shipping: "Free shipping",
    icon: Sprout,
  },
  {
    id: 2,
    name: "Organic NPK Fertilizer 10-10-10",
    category: "fertilizers",
    price: 28.5,
    originalPrice: null,
    rating: 4.6,
    reviews: 89,
    image: "/organic-fertilizer-bag.png",
    inStock: true,
    stockCount: 25,
    description: "Balanced organic fertilizer for all crops and garden plants",
    features: ["100% organic", "Slow release", "50kg bag", "All-purpose"],
    seller: "GreenGrow Organics",
    shipping: "$5.99 shipping",
    icon: Beaker,
  },
  {
    id: 3,
    name: "Professional Pruning Shears",
    category: "tools",
    price: 34.99,
    originalPrice: 42.99,
    rating: 4.9,
    reviews: 203,
    image: "/pruning-shears-garden-tool.jpg",
    inStock: true,
    stockCount: 15,
    description: "Heavy-duty pruning shears with ergonomic grip and sharp blades",
    features: ["Stainless steel", "Ergonomic grip", "Safety lock", "Lifetime warranty"],
    seller: "ToolMaster",
    shipping: "Free shipping",
    icon: Scissors,
  },
  {
    id: 4,
    name: "Tomato Seeds - Cherry Variety Pack",
    category: "seeds",
    price: 12.99,
    originalPrice: null,
    rating: 4.7,
    reviews: 156,
    image: "/tomato-seeds-packet.jpg",
    inStock: true,
    stockCount: 100,
    description: "Mixed pack of 5 different cherry tomato varieties",
    features: ["5 varieties", "Organic seeds", "High germination", "75-day harvest"],
    seller: "Heritage Seeds",
    shipping: "Free shipping",
    icon: Sprout,
  },
  {
    id: 5,
    name: "Drip Irrigation Starter Kit",
    category: "irrigation",
    price: 89.99,
    originalPrice: 109.99,
    rating: 4.5,
    reviews: 67,
    image: "/drip-irrigation-system-kit.jpg",
    inStock: true,
    stockCount: 8,
    description: "Complete drip irrigation system for small to medium gardens",
    features: ["50m tubing", "20 emitters", "Timer included", "Easy installation"],
    seller: "WaterWise Systems",
    shipping: "Free shipping",
    icon: Wrench,
  },
  {
    id: 6,
    name: "Organic Pest Control Spray",
    category: "pesticides",
    price: 19.99,
    originalPrice: null,
    rating: 4.4,
    reviews: 92,
    image: "/organic-pest-control-spray-bottle.jpg",
    inStock: false,
    stockCount: 0,
    description: "Natural pest control solution safe for organic farming",
    features: ["100% natural", "Safe for bees", "1L concentrate", "Multi-pest control"],
    seller: "EcoGuard",
    shipping: "$3.99 shipping",
    icon: Beaker,
  },
]

export default function StorePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("featured")
  const [cart, setCart] = useState<{ [key: number]: number }>({})
  const [wishlist, setWishlist] = useState<number[]>([])

  const filteredProducts = mockProducts
    .filter((product) => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
      return matchesSearch && matchesCategory
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.rating - a.rating
        case "newest":
          return b.id - a.id
        default:
          return 0
      }
    })

  const addToCart = (productId: number) => {
    const product = mockProducts.find((p) => p.id === productId)
    if (!product || !product.inStock) {
      alert("Product is out of stock")
      return
    }

    setCart((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1,
    }))

    console.log(`[v0] Added ${product.name} to cart`)
  }

  const removeFromCart = (productId: number) => {
    setCart((prev) => {
      const newCart = { ...prev }
      if (newCart[productId] > 1) {
        newCart[productId]--
      } else {
        delete newCart[productId]
      }
      return newCart
    })
  }

  const toggleWishlist = (productId: number) => {
    const product = mockProducts.find((p) => p.id === productId)
    setWishlist((prev) => {
      const isInWishlist = prev.includes(productId)
      const newWishlist = isInWishlist ? prev.filter((id) => id !== productId) : [...prev, productId]

      console.log(`[v0] ${isInWishlist ? "Removed from" : "Added to"} wishlist: ${product?.name}`)
      return newWishlist
    })
  }

  const handleCheckout = () => {
    if (cartItemsCount === 0) {
      alert("Your cart is empty")
      return
    }

    const orderSummary = Object.entries(cart)
      .map(([productId, count]) => {
        const product = mockProducts.find((p) => p.id === Number.parseInt(productId))
        return `${product?.name}: ${count} x $${product?.price} = $${((product?.price || 0) * count).toFixed(2)}`
      })
      .join("\n")

    alert(
      `Order Summary:\n\n${orderSummary}\n\nTotal: $${cartTotal.toFixed(2)}\n\nThank you for your order! This is a demo - no actual payment processed.`,
    )
    setCart({}) // Clear cart after checkout
  }

  const cartItemsCount = Object.values(cart).reduce((sum, count) => sum + count, 0)
  const cartTotal = Object.entries(cart).reduce((total, [productId, count]) => {
    const product = mockProducts.find((p) => p.id === Number.parseInt(productId))
    return total + (product?.price || 0) * count
  }, 0)

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Agricultural Store</h1>
            <p className="text-muted-foreground text-lg">Quality seeds, tools, fertilizers, and equipment</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" className="relative bg-transparent">
              <Heart className="h-4 w-4 mr-2" />
              Wishlist
              {wishlist.length > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center">
                  {wishlist.length}
                </Badge>
              )}
            </Button>
            <Button className="relative">
              <ShoppingCart className="h-4 w-4 mr-2" />
              Cart ${cartTotal.toFixed(2)}
              {cartItemsCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center">
                  {cartItemsCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-[200px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name} ({category.count})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-[150px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Store Features */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg">
          <Truck className="h-6 w-6 text-green-600" />
          <div>
            <p className="font-semibold">Free Shipping</p>
            <p className="text-sm text-muted-foreground">On orders over $50</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg">
          <Shield className="h-6 w-6 text-blue-600" />
          <div>
            <p className="font-semibold">Quality Guarantee</p>
            <p className="text-sm text-muted-foreground">100% satisfaction</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-4 bg-purple-50 rounded-lg">
          <Package className="h-6 w-6 text-purple-600" />
          <div>
            <p className="font-semibold">Fast Delivery</p>
            <p className="text-sm text-muted-foreground">2-3 business days</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-4 bg-orange-50 rounded-lg">
          <Star className="h-6 w-6 text-orange-600" />
          <div>
            <p className="font-semibold">Expert Support</p>
            <p className="text-sm text-muted-foreground">Agricultural advice</p>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="group hover:shadow-lg transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-lg mb-3"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-2 right-2 h-8 w-8 p-0 bg-white/80 hover:bg-white"
                  onClick={() => toggleWishlist(product.id)}
                >
                  <Heart
                    className={`h-4 w-4 ${
                      wishlist.includes(product.id) ? "fill-red-500 text-red-500" : "text-gray-600"
                    }`}
                  />
                </Button>
                {!product.inStock && <Badge className="absolute top-2 left-2 bg-red-500">Out of Stock</Badge>}
                {product.originalPrice && (
                  <Badge className="absolute bottom-2 left-2 bg-green-500">
                    Save ${(product.originalPrice - product.price).toFixed(2)}
                  </Badge>
                )}
              </div>
              <div className="flex items-center space-x-2 mb-2">
                <product.icon className="h-4 w-4 text-primary" />
                <Badge variant="outline" className="text-xs">
                  {categories.find((c) => c.id === product.category)?.name}
                </Badge>
              </div>
              <CardTitle className="text-lg line-clamp-2">{product.name}</CardTitle>
              <CardDescription className="line-clamp-2">{product.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  {product.rating} ({product.reviews})
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-bold text-primary">${product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">${product.originalPrice}</span>
                    )}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">{product.shipping}</p>
                <p className="text-sm font-medium">by {product.seller}</p>
              </div>

              <div className="space-y-2">
                <div className="flex flex-wrap gap-1">
                  {product.features.slice(0, 2).map((feature, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>

              {product.inStock ? (
                <div className="space-y-2">
                  {cart[product.id] ? (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeFromCart(product.id)}
                          className="h-8 w-8 p-0"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="font-medium">{cart[product.id]}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => addToCart(product.id)}
                          className="h-8 w-8 p-0"
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <span className="text-sm font-medium">${(product.price * cart[product.id]).toFixed(2)}</span>
                    </div>
                  ) : (
                    <Button onClick={() => addToCart(product.id)} className="w-full">
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Add to Cart
                    </Button>
                  )}
                  <p className="text-sm text-muted-foreground text-center">{product.stockCount} in stock</p>
                </div>
              ) : (
                <Button disabled className="w-full">
                  Out of Stock
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <Card className="py-12">
          <CardContent className="text-center">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No products found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search or filter criteria</p>
            <Button onClick={() => setSearchTerm("")}>Clear Search</Button>
          </CardContent>
        </Card>
      )}

      {/* Shopping Cart Summary */}
      {cartItemsCount > 0 && (
        <div className="fixed bottom-4 right-4 z-50">
          <Card className="w-80">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Cart Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(cart).map(([productId, count]) => {
                const product = mockProducts.find((p) => p.id === Number.parseInt(productId))
                if (!product) return null
                return (
                  <div key={productId} className="flex items-center justify-between text-sm">
                    <span className="truncate flex-1 mr-2">{product.name}</span>
                    <span>
                      {count} × ${product.price} = ${(product.price * count).toFixed(2)}
                    </span>
                  </div>
                )
              })}
              <div className="border-t pt-3">
                <div className="flex items-center justify-between font-semibold">
                  <span>Total:</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </div>
              </div>
              <Button className="w-full" onClick={handleCheckout}>
                <ShoppingCart className="h-4 w-4 mr-2" />
                Checkout
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
