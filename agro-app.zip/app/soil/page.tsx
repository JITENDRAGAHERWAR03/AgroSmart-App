"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Sprout,
  Upload,
  Camera,
  MapPin,
  Thermometer,
  Droplets,
  Zap,
  Leaf,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Info,
} from "lucide-react"

const soilTypes = [
  { name: "Clay", description: "Heavy, nutrient-rich soil with good water retention" },
  { name: "Sandy", description: "Light, well-draining soil that warms up quickly" },
  { name: "Loam", description: "Ideal balanced soil with good drainage and nutrients" },
  { name: "Silt", description: "Fine particles with good water and nutrient retention" },
]

const mockSoilData = {
  ph: 6.8,
  nitrogen: 45,
  phosphorus: 32,
  potassium: 28,
  organicMatter: 3.2,
  moisture: 22,
  temperature: 18,
  soilType: "Loam",
  healthScore: 78,
}

export default function SoilDetectionPage() {
  const [activeTab, setActiveTab] = useState("analyze")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [location, setLocation] = useState("")
  const [cropType, setCropType] = useState("")
  const [notes, setNotes] = useState("")

  const handleAnalyze = () => {
    setIsAnalyzing(true)
    // Simulate analysis
    setTimeout(() => {
      setIsAnalyzing(false)
      setShowResults(true)
    }, 3000)
  }

  const getHealthColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getHealthStatus = (score: number) => {
    if (score >= 80) return "Excellent"
    if (score >= 60) return "Good"
    return "Needs Attention"
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Soil Detection & Analysis</h1>
        <p className="text-muted-foreground text-lg">
          Advanced soil analysis to optimize your crop growth and yield potential
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="analyze">Analyze Soil</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="analyze" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Soil Sample Upload */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Upload Soil Sample</span>
                </CardTitle>
                <CardDescription>Upload a photo of your soil sample for visual analysis</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                  <Camera className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-sm text-muted-foreground mb-4">
                    Drag and drop your soil image here, or click to browse
                  </p>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Choose File
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Location & Crop Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5" />
                  <span>Location & Crop Details</span>
                </CardTitle>
                <CardDescription>Provide context for more accurate analysis</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="location">Farm Location</Label>
                  <Input
                    id="location"
                    placeholder="Enter your farm location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="crop">Intended Crop</Label>
                  <Input
                    id="crop"
                    placeholder="What crop do you plan to grow?"
                    value={cropType}
                    onChange={(e) => setCropType(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    placeholder="Any additional information about your soil..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Soil Types Reference */}
          <Card>
            <CardHeader>
              <CardTitle>Soil Types Reference</CardTitle>
              <CardDescription>Understanding different soil types and their characteristics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {soilTypes.map((soil, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">{soil.name}</h4>
                    <p className="text-sm text-muted-foreground">{soil.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button size="lg" onClick={handleAnalyze} disabled={isAnalyzing} className="px-8">
              {isAnalyzing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Analyzing Soil...
                </>
              ) : (
                <>
                  <Sprout className="h-5 w-5 mr-2" />
                  Start Analysis
                </>
              )}
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          {showResults ? (
            <>
              {/* Overall Health Score */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Soil Health Score</span>
                    <Badge
                      variant={
                        mockSoilData.healthScore >= 80
                          ? "default"
                          : mockSoilData.healthScore >= 60
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {getHealthStatus(mockSoilData.healthScore)}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-4">
                    <div className="flex-1">
                      <Progress value={mockSoilData.healthScore} className="h-3" />
                    </div>
                    <div className={`text-2xl font-bold ${getHealthColor(mockSoilData.healthScore)}`}>
                      {mockSoilData.healthScore}%
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Detailed Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Zap className="h-4 w-4 mr-2 text-blue-600" />
                      pH Level
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.ph}</div>
                    <p className="text-sm text-muted-foreground">Slightly Acidic</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Leaf className="h-4 w-4 mr-2 text-green-600" />
                      Nitrogen
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.nitrogen}%</div>
                    <p className="text-sm text-muted-foreground">Good Level</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <TrendingUp className="h-4 w-4 mr-2 text-orange-600" />
                      Phosphorus
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.phosphorus}%</div>
                    <p className="text-sm text-muted-foreground">Moderate</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Droplets className="h-4 w-4 mr-2 text-purple-600" />
                      Potassium
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.potassium}%</div>
                    <p className="text-sm text-muted-foreground">Low</p>
                  </CardContent>
                </Card>
              </div>

              {/* Additional Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Thermometer className="h-4 w-4 mr-2 text-red-600" />
                      Temperature
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.temperature}°C</div>
                    <p className="text-sm text-muted-foreground">Optimal Range</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Droplets className="h-4 w-4 mr-2 text-blue-600" />
                      Moisture
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.moisture}%</div>
                    <p className="text-sm text-muted-foreground">Good Level</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Leaf className="h-4 w-4 mr-2 text-green-600" />
                      Organic Matter
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockSoilData.organicMatter}%</div>
                    <p className="text-sm text-muted-foreground">Healthy Level</p>
                  </CardContent>
                </Card>
              </div>
            </>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Sprout className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Analysis Results Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Upload a soil sample and run the analysis to see detailed results here.
                </p>
                <Button onClick={() => setActiveTab("analyze")}>Start Analysis</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          {showResults ? (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Immediate Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <AlertTriangle className="h-5 w-5 text-orange-600" />
                      <span>Immediate Actions</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Low Potassium Detected:</strong> Consider adding potassium-rich fertilizer to improve
                        plant health and disease resistance.
                      </AlertDescription>
                    </Alert>
                    <Alert>
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Good pH Balance:</strong> Your soil pH is in the optimal range for most crops.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>

                {/* Long-term Improvements */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      <span>Long-term Improvements</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="font-medium">Add Organic Compost</p>
                        <p className="text-sm text-muted-foreground">Increase organic matter content over time</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="font-medium">Implement Crop Rotation</p>
                        <p className="text-sm text-muted-foreground">
                          Maintain soil health and prevent nutrient depletion
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="font-medium">Regular Testing</p>
                        <p className="text-sm text-muted-foreground">Monitor soil health every 6 months</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Fertilizer Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Fertilizers</CardTitle>
                  <CardDescription>Based on your soil analysis results</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Potassium Sulfate</h4>
                      <p className="text-sm text-muted-foreground mb-2">For potassium deficiency</p>
                      <Badge variant="secondary">High Priority</Badge>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Balanced NPK (10-10-10)</h4>
                      <p className="text-sm text-muted-foreground mb-2">General maintenance</p>
                      <Badge variant="outline">Medium Priority</Badge>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Organic Compost</h4>
                      <p className="text-sm text-muted-foreground mb-2">Long-term soil health</p>
                      <Badge variant="outline">Ongoing</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Recommendations Available</h3>
                <p className="text-muted-foreground mb-4">
                  Complete the soil analysis to receive personalized recommendations.
                </p>
                <Button onClick={() => setActiveTab("analyze")}>Start Analysis</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
