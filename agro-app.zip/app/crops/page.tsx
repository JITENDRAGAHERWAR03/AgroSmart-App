"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Calendar, Droplets, Sun, CheckCircle, Sprout, Wheat, Apple, Carrot } from "lucide-react"

const cropCategories = [
  { id: "all", name: "All Crops", count: 85 },
  { id: "grains", name: "Grains & Cereals", count: 18 },
  { id: "vegetables", name: "Vegetables", count: 25 },
  { id: "fruits", name: "Fruits", count: 15 },
  { id: "legumes", name: "Legumes & Pulses", count: 12 },
  { id: "spices", name: "Spices & Condiments", count: 10 },
  { id: "cash", name: "Cash Crops", count: 5 },
]

const mockCrops = [
  // Grains & Cereals
  {
    id: 1,
    name: "Rice (Chawal)",
    category: "grains",
    icon: Wheat,
    difficulty: "Medium",
    season: "Kharif (June-October)",
    growingTime: "120-150 days",
    yield: "3-6 tons/hectare",
    waterNeeds: "High",
    soilType: "Clay loam, well-drained",
    temperature: "20-35°C",
    regions: "Punjab, Haryana, West Bengal, Andhra Pradesh, Tamil Nadu",
    description: "India's staple food crop, grown in both Kharif and Rabi seasons",
    plantingDepth: "2-3 cm",
    spacing: "20x15 cm",
    fertilizer: "High nitrogen, moderate phosphorus and potassium",
    pests: ["Brown planthopper", "Stem borer", "Leaf folder"],
    diseases: ["Blast", "Bacterial blight", "Sheath rot"],
    harvestTime: "When 80% of grains turn golden yellow",
  },
  {
    id: 2,
    name: "Wheat (Gehun)",
    category: "grains",
    icon: Wheat,
    difficulty: "Easy",
    season: "Rabi (November-April)",
    growingTime: "120-150 days",
    yield: "3-5 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained loamy soil",
    temperature: "15-25°C",
    regions: "Punjab, Haryana, Uttar Pradesh, Madhya Pradesh, Rajasthan",
    description: "Second most important cereal crop in India",
    plantingDepth: "3-5 cm",
    spacing: "22.5 cm row spacing",
    fertilizer: "Nitrogen-rich with phosphorus",
    pests: ["Aphids", "Termites", "Army worm"],
    diseases: ["Rust", "Smut", "Karnal bunt"],
    harvestTime: "When grains are hard and moisture content is 12-14%",
  },
  {
    id: 3,
    name: "Maize (Makka)",
    category: "grains",
    icon: Wheat,
    difficulty: "Medium",
    season: "Kharif & Rabi",
    growingTime: "90-120 days",
    yield: "4-8 tons/hectare",
    waterNeeds: "Medium-High",
    soilType: "Well-drained fertile soil",
    temperature: "18-27°C",
    regions: "Karnataka, Andhra Pradesh, Tamil Nadu, Rajasthan, Maharashtra",
    description: "Third most important cereal crop, used for food and feed",
    plantingDepth: "3-5 cm",
    spacing: "60x20 cm",
    fertilizer: "High nitrogen requirement",
    pests: ["Stem borer", "Fall armyworm", "Shoot fly"],
    diseases: ["Maydis leaf blight", "Common rust", "Downy mildew"],
    harvestTime: "When kernels are hard and moisture is 15-20%",
  },
  {
    id: 4,
    name: "Bajra (Pearl Millet)",
    category: "grains",
    icon: Wheat,
    difficulty: "Easy",
    season: "Kharif (June-September)",
    growingTime: "70-90 days",
    yield: "1-2 tons/hectare",
    waterNeeds: "Low",
    soilType: "Sandy loam, drought tolerant",
    temperature: "25-35°C",
    regions: "Rajasthan, Gujarat, Haryana, Maharashtra, Karnataka",
    description: "Drought-resistant millet crop, important in arid regions",
    plantingDepth: "2-3 cm",
    spacing: "45x10 cm",
    fertilizer: "Low nitrogen requirement",
    pests: ["Shoot fly", "Stem borer", "Downy mildew"],
    diseases: ["Ergot", "Smut", "Blast"],
    harvestTime: "When earheads turn brown and grains are hard",
  },
  {
    id: 5,
    name: "Jowar (Sorghum)",
    category: "grains",
    icon: Wheat,
    difficulty: "Easy",
    season: "Kharif & Rabi",
    growingTime: "90-120 days",
    yield: "1.5-3 tons/hectare",
    waterNeeds: "Low-Medium",
    soilType: "Well-drained, drought tolerant",
    temperature: "26-30°C",
    regions: "Maharashtra, Karnataka, Andhra Pradesh, Madhya Pradesh, Rajasthan",
    description: "Drought-resistant cereal, important food grain in semi-arid regions",
    plantingDepth: "2-3 cm",
    spacing: "45x15 cm",
    fertilizer: "Moderate nitrogen and phosphorus",
    pests: ["Shoot fly", "Stem borer", "Aphids"],
    diseases: ["Grain mold", "Leaf blight", "Downy mildew"],
    harvestTime: "When grains are hard and physiologically mature",
  },

  // Legumes & Pulses
  {
    id: 6,
    name: "Arhar (Pigeon Pea/Tur)",
    category: "legumes",
    icon: Sprout,
    difficulty: "Medium",
    season: "Kharif (June-March)",
    growingTime: "150-200 days",
    yield: "1-2 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained black cotton soil",
    temperature: "20-30°C",
    regions: "Maharashtra, Karnataka, Madhya Pradesh, Andhra Pradesh, Gujarat",
    description: "Major pulse crop, important source of protein",
    plantingDepth: "3-4 cm",
    spacing: "30x10 cm",
    fertilizer: "Low nitrogen (fixes nitrogen), phosphorus and potassium",
    pests: ["Pod borer", "Pod fly", "Plume moth"],
    diseases: ["Wilt", "Sterility mosaic", "Phytophthora blight"],
    harvestTime: "When pods turn brown and rattle when shaken",
  },
  {
    id: 7,
    name: "Chana (Chickpea/Gram)",
    category: "legumes",
    icon: Sprout,
    difficulty: "Medium",
    season: "Rabi (October-April)",
    growingTime: "90-120 days",
    yield: "1.5-2.5 tons/hectare",
    waterNeeds: "Low-Medium",
    soilType: "Well-drained loamy soil",
    temperature: "15-25°C",
    regions: "Madhya Pradesh, Rajasthan, Maharashtra, Uttar Pradesh, Karnataka",
    description: "Most important pulse crop in India",
    plantingDepth: "3-4 cm",
    spacing: "30x10 cm",
    fertilizer: "Phosphorus and potassium, minimal nitrogen",
    pests: ["Pod borer", "Cutworm", "Aphids"],
    diseases: ["Wilt", "Blight", "Root rot"],
    harvestTime: "When pods are dry and brown",
  },
  {
    id: 8,
    name: "Moong (Green Gram)",
    category: "legumes",
    icon: Sprout,
    difficulty: "Easy",
    season: "Kharif & Summer",
    growingTime: "60-90 days",
    yield: "0.8-1.5 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "25-35°C",
    regions: "Rajasthan, Maharashtra, Andhra Pradesh, Karnataka, Odisha",
    description: "Short duration pulse crop, can be grown in multiple seasons",
    plantingDepth: "2-3 cm",
    spacing: "30x10 cm",
    fertilizer: "Phosphorus and potassium",
    pests: ["Thrips", "Whitefly", "Pod borer"],
    diseases: ["Yellow mosaic virus", "Powdery mildew", "Cercospora leaf spot"],
    harvestTime: "When pods turn black and dry",
  },

  // Vegetables
  {
    id: 9,
    name: "Tomato (Tamatar)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Medium",
    season: "Kharif & Rabi",
    growingTime: "70-90 days",
    yield: "25-50 tons/hectare",
    waterNeeds: "High",
    soilType: "Well-drained fertile loamy soil",
    temperature: "20-25°C",
    regions: "Andhra Pradesh, Karnataka, Odisha, West Bengal, Maharashtra",
    description: "Most important vegetable crop with high nutritional value",
    plantingDepth: "1-2 cm (seedling)",
    spacing: "60x45 cm",
    fertilizer: "High nitrogen, phosphorus, and potassium",
    pests: ["Fruit borer", "Whitefly", "Leaf miner"],
    diseases: ["Early blight", "Late blight", "Bacterial wilt"],
    harvestTime: "When fruits are fully developed but still firm",
  },
  {
    id: 10,
    name: "Onion (Pyaz)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Medium",
    season: "Kharif & Rabi",
    growingTime: "120-150 days",
    yield: "15-25 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "15-25°C",
    regions: "Maharashtra, Gujarat, Karnataka, Andhra Pradesh, Madhya Pradesh",
    description: "Important commercial vegetable crop and export commodity",
    plantingDepth: "2-3 cm",
    spacing: "15x10 cm",
    fertilizer: "High nitrogen and potassium",
    pests: ["Thrips", "Cutworm", "Onion fly"],
    diseases: ["Purple blotch", "Downy mildew", "Basal rot"],
    harvestTime: "When neck becomes soft and tops fall over",
  },
  {
    id: 11,
    name: "Potato (Aloo)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Medium",
    season: "Rabi (October-March)",
    growingTime: "90-120 days",
    yield: "20-40 tons/hectare",
    waterNeeds: "Medium-High",
    soilType: "Well-drained sandy loam",
    temperature: "15-20°C",
    regions: "Uttar Pradesh, West Bengal, Bihar, Gujarat, Madhya Pradesh",
    description: "Important tuber crop, staple food in many regions",
    plantingDepth: "5-7 cm",
    spacing: "60x20 cm",
    fertilizer: "High potassium, moderate nitrogen and phosphorus",
    pests: ["Potato tuber moth", "Aphids", "Cutworm"],
    diseases: ["Late blight", "Early blight", "Black scurf"],
    harvestTime: "When plants turn yellow and tubers are mature",
  },
  {
    id: 12,
    name: "Brinjal (Baingan)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Medium",
    season: "Year-round",
    growingTime: "120-150 days",
    yield: "15-30 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained fertile soil",
    temperature: "22-27°C",
    regions: "West Bengal, Odisha, Karnataka, Andhra Pradesh, Maharashtra",
    description: "Popular vegetable crop grown throughout India",
    plantingDepth: "1-2 cm (seedling)",
    spacing: "75x60 cm",
    fertilizer: "Balanced NPK with organic matter",
    pests: ["Fruit and shoot borer", "Aphids", "Jassids"],
    diseases: ["Bacterial wilt", "Phomopsis blight", "Little leaf"],
    harvestTime: "When fruits are tender and glossy",
  },
  {
    id: 13,
    name: "Okra (Bhindi)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Easy",
    season: "Kharif & Summer",
    growingTime: "50-60 days",
    yield: "8-12 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained loamy soil",
    temperature: "25-35°C",
    regions: "Andhra Pradesh, Gujarat, Maharashtra, Karnataka, Tamil Nadu",
    description: "Heat-tolerant vegetable crop with continuous harvest",
    plantingDepth: "2-3 cm",
    spacing: "45x30 cm",
    fertilizer: "Moderate nitrogen, phosphorus, and potassium",
    pests: ["Shoot and fruit borer", "Aphids", "Jassids"],
    diseases: ["Yellow vein mosaic virus", "Powdery mildew", "Cercospora leaf spot"],
    harvestTime: "When pods are tender, 4-6 days after flowering",
  },

  // Fruits
  {
    id: 14,
    name: "Mango (Aam)",
    category: "fruits",
    icon: Apple,
    difficulty: "Hard",
    season: "Perennial (March-June harvest)",
    growingTime: "3-5 years to fruit",
    yield: "10-15 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained deep soil",
    temperature: "24-30°C",
    regions: "Uttar Pradesh, Andhra Pradesh, Karnataka, Gujarat, Tamil Nadu",
    description: "King of fruits, major export commodity",
    plantingDepth: "Root level",
    spacing: "10x10 meters",
    fertilizer: "Balanced NPK with micronutrients",
    pests: ["Mango hopper", "Fruit fly", "Scale insects"],
    diseases: ["Anthracnose", "Powdery mildew", "Malformation"],
    harvestTime: "When fruits develop characteristic color and aroma",
  },
  {
    id: 15,
    name: "Banana (Kela)",
    category: "fruits",
    icon: Apple,
    difficulty: "Medium",
    season: "Year-round",
    growingTime: "12-15 months",
    yield: "40-60 tons/hectare",
    waterNeeds: "High",
    soilType: "Rich, well-drained soil",
    temperature: "26-30°C",
    regions: "Tamil Nadu, Maharashtra, Gujarat, Andhra Pradesh, Karnataka",
    description: "Important fruit crop with year-round production",
    plantingDepth: "30-45 cm",
    spacing: "2x2 meters",
    fertilizer: "High potassium, moderate nitrogen",
    pests: ["Nematodes", "Aphids", "Thrips"],
    diseases: ["Panama wilt", "Sigatoka", "Bunchy top virus"],
    harvestTime: "When fingers are plump and ridges become less prominent",
  },
  {
    id: 16,
    name: "Citrus (Santra/Nimbu)",
    category: "fruits",
    icon: Apple,
    difficulty: "Medium",
    season: "Perennial (November-February harvest)",
    growingTime: "3-4 years to fruit",
    yield: "15-25 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "20-30°C",
    regions: "Maharashtra, Andhra Pradesh, Punjab, Haryana, Karnataka",
    description: "Important citrus fruits including oranges, lemons, and limes",
    plantingDepth: "Root level",
    spacing: "6x6 meters",
    fertilizer: "Balanced NPK with micronutrients",
    pests: ["Citrus psylla", "Scale insects", "Leaf miner"],
    diseases: ["Citrus canker", "Gummosis", "Tristeza virus"],
    harvestTime: "When fruits develop full color and sweetness",
  },

  // Spices & Condiments
  {
    id: 17,
    name: "Turmeric (Haldi)",
    category: "spices",
    icon: Sprout,
    difficulty: "Medium",
    season: "Kharif (June-March)",
    growingTime: "240-300 days",
    yield: "15-25 tons/hectare",
    waterNeeds: "Medium-High",
    soilType: "Well-drained fertile loamy soil",
    temperature: "20-30°C",
    regions: "Andhra Pradesh, Tamil Nadu, Karnataka, Odisha, West Bengal",
    description: "Important spice crop with medicinal properties",
    plantingDepth: "3-5 cm",
    spacing: "25x25 cm",
    fertilizer: "High organic matter, moderate NPK",
    pests: ["Rhizome scale", "Shoot borer", "Leaf roller"],
    diseases: ["Rhizome rot", "Leaf spot", "Leaf blotch"],
    harvestTime: "When leaves turn yellow and dry up (7-10 months)",
  },
  {
    id: 18,
    name: "Chilli (Mirchi)",
    category: "spices",
    icon: Apple,
    difficulty: "Medium",
    season: "Kharif & Rabi",
    growingTime: "120-150 days",
    yield: "8-15 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "20-30°C",
    regions: "Andhra Pradesh, Karnataka, Maharashtra, Tamil Nadu, Gujarat",
    description: "Important spice crop, both for domestic use and export",
    plantingDepth: "1-2 cm (seedling)",
    spacing: "45x30 cm",
    fertilizer: "Moderate nitrogen, high phosphorus and potassium",
    pests: ["Thrips", "Aphids", "Fruit borer"],
    diseases: ["Anthracnose", "Bacterial wilt", "Leaf curl virus"],
    harvestTime: "When fruits turn red and dry (green harvest for fresh market)",
  },
  {
    id: 19,
    name: "Coriander (Dhania)",
    category: "spices",
    icon: Sprout,
    difficulty: "Easy",
    season: "Rabi (October-March)",
    growingTime: "90-120 days",
    yield: "1-2 tons/hectare",
    waterNeeds: "Low-Medium",
    soilType: "Well-drained loamy soil",
    temperature: "15-25°C",
    regions: "Rajasthan, Gujarat, Madhya Pradesh, Andhra Pradesh, Karnataka",
    description: "Dual-purpose crop for leaves (cilantro) and seeds (coriander)",
    plantingDepth: "1-2 cm",
    spacing: "30x10 cm",
    fertilizer: "Low nitrogen, moderate phosphorus",
    pests: ["Aphids", "Coriander aphid", "Stem gall fly"],
    diseases: ["Wilt", "Powdery mildew", "Stem rot"],
    harvestTime: "When seeds turn brown and aromatic",
  },

  // Cash Crops
  {
    id: 20,
    name: "Cotton (Kapas)",
    category: "cash",
    icon: Sprout,
    difficulty: "Hard",
    season: "Kharif (May-December)",
    growingTime: "180-200 days",
    yield: "1.5-3 tons/hectare",
    waterNeeds: "Medium-High",
    soilType: "Deep black cotton soil",
    temperature: "21-30°C",
    regions: "Gujarat, Maharashtra, Andhra Pradesh, Karnataka, Haryana",
    description: "Major fiber crop, important for textile industry",
    plantingDepth: "2-3 cm",
    spacing: "45x15 cm",
    fertilizer: "High nitrogen, moderate phosphorus and potassium",
    pests: ["Bollworm", "Aphids", "Jassids", "Thrips"],
    diseases: ["Wilt", "Root rot", "Leaf curl virus"],
    harvestTime: "When bolls burst open and cotton is fluffy white",
  },
  {
    id: 21,
    name: "Sugarcane (Ganna)",
    category: "cash",
    icon: Wheat,
    difficulty: "Hard",
    season: "Year-round planting",
    growingTime: "300-365 days",
    yield: "60-100 tons/hectare",
    waterNeeds: "High",
    soilType: "Deep fertile soil with good drainage",
    temperature: "20-30°C",
    regions: "Uttar Pradesh, Maharashtra, Karnataka, Tamil Nadu, Gujarat",
    description: "Major sugar-producing crop, also used for jaggery and ethanol",
    plantingDepth: "5-7 cm",
    spacing: "90-120 cm rows",
    fertilizer: "High nitrogen, moderate phosphorus and potassium",
    pests: ["Early shoot borer", "Top borer", "White grub"],
    diseases: ["Red rot", "Smut", "Wilt"],
    harvestTime: "When canes are mature (10-18 months depending on variety)",
  },

  // Additional vegetables
  {
    id: 22,
    name: "Cabbage (Patta Gobi)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Medium",
    season: "Rabi (October-March)",
    growingTime: "90-120 days",
    yield: "40-60 tons/hectare",
    waterNeeds: "Medium-High",
    soilType: "Well-drained fertile soil",
    temperature: "15-20°C",
    regions: "Karnataka, Maharashtra, Odisha, West Bengal, Uttar Pradesh",
    description: "Cool season vegetable crop with good storage quality",
    plantingDepth: "1-2 cm (seedling)",
    spacing: "45x45 cm",
    fertilizer: "High nitrogen, moderate phosphorus and potassium",
    pests: ["Diamond back moth", "Aphids", "Cutworm"],
    diseases: ["Black rot", "Club root", "Downy mildew"],
    harvestTime: "When heads are firm and compact",
  },
  {
    id: 23,
    name: "Cauliflower (Phool Gobi)",
    category: "vegetables",
    icon: Apple,
    difficulty: "Medium",
    season: "Rabi (October-February)",
    growingTime: "80-120 days",
    yield: "20-35 tons/hectare",
    waterNeeds: "Medium-High",
    soilType: "Well-drained fertile loamy soil",
    temperature: "15-20°C",
    regions: "Bihar, Uttar Pradesh, Odisha, West Bengal, Haryana",
    description: "Cool season vegetable requiring specific temperature conditions",
    plantingDepth: "1-2 cm (seedling)",
    spacing: "45x45 cm",
    fertilizer: "High nitrogen and potassium",
    pests: ["Diamond back moth", "Aphids", "Cabbage caterpillar"],
    diseases: ["Black rot", "Downy mildew", "Club root"],
    harvestTime: "When curds are compact and white",
  },
  {
    id: 24,
    name: "Carrot (Gajar)",
    category: "vegetables",
    icon: Carrot,
    difficulty: "Easy",
    season: "Rabi (October-March)",
    growingTime: "90-120 days",
    yield: "20-40 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Deep, loose, well-drained sandy loam",
    temperature: "16-20°C",
    regions: "Haryana, Punjab, Uttar Pradesh, Karnataka, Tamil Nadu",
    description: "Root vegetable rich in beta-carotene and vitamins",
    plantingDepth: "1-2 cm",
    spacing: "25x5 cm",
    fertilizer: "Low nitrogen, high phosphorus and potassium",
    pests: ["Carrot fly", "Aphids", "Cutworm"],
    diseases: ["Leaf blight", "Root rot", "Powdery mildew"],
    harvestTime: "When roots attain good color and size",
  },

  // Additional fruits
  {
    id: 25,
    name: "Grapes (Angoor)",
    category: "fruits",
    icon: Apple,
    difficulty: "Hard",
    season: "Perennial (December-April harvest)",
    growingTime: "2-3 years to fruit",
    yield: "20-40 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "15-35°C",
    regions: "Maharashtra, Karnataka, Andhra Pradesh, Tamil Nadu, Punjab",
    description: "Important fruit crop for fresh consumption, raisins, and wine",
    plantingDepth: "Root level",
    spacing: "3x2 meters",
    fertilizer: "Balanced NPK with micronutrients",
    pests: ["Thrips", "Mealybugs", "Flea beetle"],
    diseases: ["Downy mildew", "Powdery mildew", "Anthracnose"],
    harvestTime: "When berries develop full color and sweetness",
  },
  {
    id: 26,
    name: "Pomegranate (Anar)",
    category: "fruits",
    icon: Apple,
    difficulty: "Medium",
    season: "Perennial (October-February harvest)",
    growingTime: "2-3 years to fruit",
    yield: "12-25 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "15-35°C",
    regions: "Maharashtra, Karnataka, Andhra Pradesh, Gujarat, Rajasthan",
    description: "Drought-tolerant fruit crop with high antioxidant content",
    plantingDepth: "Root level",
    spacing: "4x4 meters",
    fertilizer: "Moderate NPK with organic matter",
    pests: ["Aphids", "Thrips", "Fruit borer"],
    diseases: ["Bacterial blight", "Wilt", "Fruit rot"],
    harvestTime: "When fruits develop characteristic color and metallic sound when tapped",
  },

  // Additional spices
  {
    id: 27,
    name: "Ginger (Adrak)",
    category: "spices",
    icon: Sprout,
    difficulty: "Medium",
    season: "Kharif (April-December)",
    growingTime: "240-270 days",
    yield: "15-25 tons/hectare",
    waterNeeds: "High",
    soilType: "Well-drained fertile loamy soil",
    temperature: "25-30°C",
    regions: "Kerala, Karnataka, Assam, Himachal Pradesh, Uttarakhand",
    description: "Important spice and medicinal crop",
    plantingDepth: "3-5 cm",
    spacing: "25x20 cm",
    fertilizer: "High organic matter, moderate NPK",
    pests: ["Rhizome scale", "Shoot borer", "Soft rot"],
    diseases: ["Rhizome rot", "Leaf spot", "Bacterial wilt"],
    harvestTime: "When leaves turn yellow and dry (8-9 months)",
  },
  {
    id: 28,
    name: "Garlic (Lahsun)",
    category: "spices",
    icon: Sprout,
    difficulty: "Easy",
    season: "Rabi (October-April)",
    growingTime: "150-180 days",
    yield: "8-15 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained sandy loam",
    temperature: "15-20°C",
    regions: "Gujarat, Madhya Pradesh, Rajasthan, Uttar Pradesh, Haryana",
    description: "Important condiment crop with medicinal properties",
    plantingDepth: "2-3 cm",
    spacing: "15x10 cm",
    fertilizer: "High nitrogen and potassium",
    pests: ["Thrips", "Onion fly", "Cutworm"],
    diseases: ["Purple blotch", "White rot", "Downy mildew"],
    harvestTime: "When leaves turn yellow and bulbs are well formed",
  },

  // Additional legumes
  {
    id: 29,
    name: "Urad (Black Gram)",
    category: "legumes",
    icon: Sprout,
    difficulty: "Medium",
    season: "Kharif & Rabi",
    growingTime: "75-90 days",
    yield: "0.8-1.5 tons/hectare",
    waterNeeds: "Medium",
    soilType: "Well-drained loamy soil",
    temperature: "25-35°C",
    regions: "Andhra Pradesh, Maharashtra, Madhya Pradesh, Uttar Pradesh, Tamil Nadu",
    description: "Important pulse crop used for dal and various preparations",
    plantingDepth: "2-3 cm",
    spacing: "30x10 cm",
    fertilizer: "Phosphorus and potassium, minimal nitrogen",
    pests: ["Pod borer", "Aphids", "Thrips"],
    diseases: ["Yellow mosaic virus", "Powdery mildew", "Cercospora leaf spot"],
    harvestTime: "When pods turn black and dry",
  },
  {
    id: 30,
    name: "Masoor (Lentil)",
    category: "legumes",
    icon: Sprout,
    difficulty: "Easy",
    season: "Rabi (October-April)",
    growingTime: "95-110 days",
    yield: "1-1.8 tons/hectare",
    waterNeeds: "Low-Medium",
    soilType: "Well-drained loamy soil",
    temperature: "15-25°C",
    regions: "Uttar Pradesh, Madhya Pradesh, Bihar, West Bengal, Jharkhand",
    description: "Cool season pulse crop, important protein source",
    plantingDepth: "2-3 cm",
    spacing: "25x5 cm",
    fertilizer: "Phosphorus and potassium",
    pests: ["Aphids", "Pod borer", "Cutworm"],
    diseases: ["Wilt", "Rust", "Blight"],
    harvestTime: "When pods are dry and brown",
  },
]

function getDifficultyColor(difficulty: string) {
  switch (difficulty) {
    case "Easy":
      return "bg-green-100 text-green-800"
    case "Medium":
      return "bg-yellow-100 text-yellow-800"
    case "Hard":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export default function CropsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedCrop, setSelectedCrop] = useState<(typeof mockCrops)[0] | null>(null)
  const [activeTab, setActiveTab] = useState("browse")

  const filteredCrops = mockCrops.filter((crop) => {
    const matchesSearch = crop.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || crop.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const currentSeason = "Rabi" // This would be dynamic in a real app

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Indian Crop Information Center</h1>
        <p className="text-muted-foreground text-lg">
          Comprehensive database of crops grown in India with regional and seasonal information
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="browse">Browse Crops</TabsTrigger>
          <TabsTrigger value="seasonal">Seasonal Guide</TabsTrigger>
          <TabsTrigger value="planner">Crop Planner</TabsTrigger>
          <TabsTrigger value="calendar">Growing Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          {/* Search and Filter */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search crops (e.g., Rice, Wheat, Tomato)..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full md:w-[250px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {cropCategories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name} ({category.count})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Crop Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCrops.map((crop) => (
              <Card
                key={crop.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/20"
                onClick={() => setSelectedCrop(crop)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <crop.icon className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle className="text-lg">{crop.name}</CardTitle>
                    </div>
                    <Badge className={getDifficultyColor(crop.difficulty)}>{crop.difficulty}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">{crop.description}</CardDescription>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Growing Time:</span>
                      <span className="font-medium">{crop.growingTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Season:</span>
                      <span className="font-medium">{crop.season}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Yield:</span>
                      <span className="font-medium">{crop.yield}</span>
                    </div>
                    <div className="pt-2 border-t">
                      <span className="text-muted-foreground text-xs">Main Regions:</span>
                      <p className="text-xs font-medium mt-1 line-clamp-2">{crop.regions}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="seasonal" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Sun className="h-5 w-5 text-yellow-500" />
                <span>{currentSeason} Season Planting Guide</span>
              </CardTitle>
              <CardDescription>Recommended crops for the current season in India</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3 text-green-600">Ideal for Planting Now (Rabi Season)</h4>
                  <div className="space-y-2">
                    {mockCrops
                      .filter((crop) => crop.season.includes("Rabi"))
                      .slice(0, 6)
                      .map((crop) => (
                        <div key={crop.id} className="flex items-center space-x-3 p-2 border rounded">
                          <crop.icon className="h-4 w-4 text-green-600" />
                          <span className="font-medium">{crop.name}</span>
                          <Badge variant="outline" className="ml-auto">
                            {crop.growingTime}
                          </Badge>
                        </div>
                      ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3 text-orange-600">Plan for Kharif Season</h4>
                  <div className="space-y-2">
                    {mockCrops
                      .filter((crop) => crop.season.includes("Kharif"))
                      .slice(0, 6)
                      .map((crop) => (
                        <div key={crop.id} className="flex items-center space-x-3 p-2 border rounded">
                          <crop.icon className="h-4 w-4 text-orange-600" />
                          <span className="font-medium">{crop.name}</span>
                          <Badge variant="outline" className="ml-auto">
                            {crop.growingTime}
                          </Badge>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Seasonal Tips for Indian Agriculture</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <Sprout className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">Rabi Season Prep</h4>
                  <p className="text-sm text-muted-foreground">
                    October-November is ideal for wheat, gram, and mustard sowing. Ensure proper soil moisture.
                  </p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <Droplets className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Monsoon Management</h4>
                  <p className="text-sm text-muted-foreground">
                    Kharif crops depend on monsoon. Plan drainage and water conservation for dry spells.
                  </p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg">
                  <Sun className="h-6 w-6 text-yellow-600 mb-2" />
                  <h4 className="font-semibold mb-2">Summer Crops</h4>
                  <p className="text-sm text-muted-foreground">
                    Grow heat-tolerant crops like okra, bottle gourd, and fodder crops during summer.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ... existing code for other tabs ... */}
        <TabsContent value="planner" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Indian Crop Rotation System</CardTitle>
              <CardDescription>Traditional and modern crop rotation practices for Indian agriculture</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Kharif Season</h4>
                  <div className="space-y-2">
                    <div className="p-2 bg-green-100 rounded text-sm">Rice/Cotton</div>
                    <p className="text-xs text-muted-foreground">June-October (Monsoon dependent)</p>
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Rabi Season</h4>
                  <div className="space-y-2">
                    <div className="p-2 bg-yellow-100 rounded text-sm">Wheat/Gram</div>
                    <p className="text-xs text-muted-foreground">November-April (Winter crops)</p>
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">Zaid Season</h4>
                  <div className="space-y-2">
                    <div className="p-2 bg-blue-100 rounded text-sm">Fodder/Vegetables</div>
                    <p className="text-xs text-muted-foreground">April-June (Summer crops)</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Regional Crop Combinations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3 flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    North India (Punjab, Haryana)
                  </h4>
                  <div className="space-y-2">
                    <div className="p-3 border rounded">
                      <div className="font-medium">Rice-Wheat System</div>
                      <p className="text-sm text-muted-foreground">Traditional rotation in Indo-Gangetic plains</p>
                    </div>
                    <div className="p-3 border rounded">
                      <div className="font-medium">Cotton-Wheat System</div>
                      <p className="text-sm text-muted-foreground">Common in Punjab and Haryana</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3 flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    South India (Karnataka, Andhra Pradesh)
                  </h4>
                  <div className="space-y-2">
                    <div className="p-3 border rounded">
                      <div className="font-medium">Rice-Groundnut System</div>
                      <p className="text-sm text-muted-foreground">Popular in coastal regions</p>
                    </div>
                    <div className="p-3 border rounded">
                      <div className="font-medium">Cotton-Jowar System</div>
                      <p className="text-sm text-muted-foreground">Suitable for black cotton soils</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Indian Agricultural Calendar - {currentSeason} Season 2024</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold mb-2">October</h4>
                    <ul className="text-sm space-y-1">
                      <li>• Sow wheat and gram</li>
                      <li>• Plant mustard and peas</li>
                      <li>• Harvest kharif crops</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <h4 className="font-semibold mb-2">November</h4>
                    <ul className="text-sm space-y-1">
                      <li>• Continue rabi sowing</li>
                      <li>• Plant potato and onion</li>
                      <li>• Prepare for winter vegetables</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold mb-2">December</h4>
                    <ul className="text-sm space-y-1">
                      <li>• Monitor wheat growth</li>
                      <li>• Harvest sugarcane</li>
                      <li>• Plant winter vegetables</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold mb-2">January</h4>
                    <ul className="text-sm space-y-1">
                      <li>• Apply fertilizers to rabi crops</li>
                      <li>• Harvest winter vegetables</li>
                      <li>• Prepare for summer crops</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Regional Harvest Calendar</CardTitle>
              <CardDescription>Expected harvest times for major crops across India</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { crop: "Wheat", icon: Wheat, region: "North India", harvest: "March-April" },
                  { crop: "Rice", icon: Wheat, region: "All India", harvest: "October-December" },
                  { crop: "Cotton", icon: Sprout, region: "Central/South India", harvest: "October-January" },
                  { crop: "Sugarcane", icon: Wheat, region: "Uttar Pradesh, Maharashtra", harvest: "December-March" },
                ].map((item, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <item.icon className="h-5 w-5 text-primary" />
                    <div className="flex-1">
                      <div className="font-medium">{item.crop}</div>
                      <div className="text-sm text-muted-foreground">{item.region}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">Harvest Period</div>
                      <div className="text-sm text-muted-foreground">{item.harvest}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Crop Detail Modal */}
      {selectedCrop && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <selectedCrop.icon className="h-8 w-8 text-primary" />
                  <CardTitle className="text-2xl">{selectedCrop.name}</CardTitle>
                </div>
                <Button variant="ghost" onClick={() => setSelectedCrop(null)}>
                  ×
                </Button>
              </div>
              <CardDescription>{selectedCrop.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Growing Conditions</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Difficulty:</span>
                      <Badge className={getDifficultyColor(selectedCrop.difficulty)}>{selectedCrop.difficulty}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Season:</span>
                      <span>{selectedCrop.season}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Growing Time:</span>
                      <span>{selectedCrop.growingTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Temperature:</span>
                      <span>{selectedCrop.temperature}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Planting Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Depth:</span>
                      <span>{selectedCrop.plantingDepth}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Spacing:</span>
                      <span>{selectedCrop.spacing}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Water Needs:</span>
                      <span>{selectedCrop.waterNeeds}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Soil Type:</span>
                      <span>{selectedCrop.soilType}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Major Growing Regions in India</h4>
                <p className="text-sm text-muted-foreground">{selectedCrop.regions}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Fertilizer Requirements</h4>
                <p className="text-sm text-muted-foreground">{selectedCrop.fertilizer}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Common Pests</h4>
                  <div className="space-y-1">
                    {selectedCrop.pests.map((pest, index) => (
                      <Badge key={index} variant="outline" className="mr-1 mb-1">
                        {pest}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Common Diseases</h4>
                  <div className="space-y-1">
                    {selectedCrop.diseases.map((disease, index) => (
                      <Badge key={index} variant="outline" className="mr-1 mb-1">
                        {disease}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Harvest Information</h4>
                <p className="text-sm text-muted-foreground">{selectedCrop.harvestTime}</p>
                <div className="mt-2">
                  <span className="text-sm font-medium">Expected Yield: </span>
                  <span className="text-sm text-muted-foreground">{selectedCrop.yield}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
