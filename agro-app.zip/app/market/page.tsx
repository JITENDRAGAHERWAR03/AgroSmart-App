"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  TrendingUp,
  TrendingDown,
  RefreshCw,
  BarChart3,
  Calendar,
  Globe,
  AlertCircle,
  Clock,
  DollarSign,
} from "lucide-react"

interface MarketData {
  commodity: string
  price: number
  change: number
  changePercent: number
  volume: string
  high: number
  low: number
  lastUpdated: string
  category: string
  description: string
}

interface MarketNews {
  id: number
  title: string
  summary: string
  timestamp: string
  impact: "high" | "medium" | "low"
  category: string
}

const initialMarketData: MarketData[] = [
  {
    commodity: "Corn",
    price: 245.5,
    change: +12.3,
    changePercent: +5.3,
    volume: "2.4M tons",
    high: 248.0,
    low: 232.1,
    lastUpdated: new Date().toLocaleTimeString(),
    category: "Grains",
    description: "Yellow corn, #2 grade, Chicago Board of Trade",
  },
  {
    commodity: "Wheat",
    price: 189.75,
    change: -8.45,
    changePercent: -4.3,
    volume: "1.8M tons",
    high: 195.2,
    low: 185.3,
    lastUpdated: new Date().toLocaleTimeString(),
    category: "Grains",
    description: "Hard red winter wheat, Kansas City Board of Trade",
  },
  {
    commodity: "Soybeans",
    price: 412.8,
    change: +15.6,
    changePercent: +3.9,
    volume: "1.2M tons",
    high: 418.5,
    low: 398.2,
    lastUpdated: new Date().toLocaleTimeString(),
    category: "Oilseeds",
    description: "#1 yellow soybeans, Chicago Board of Trade",
  },
  {
    commodity: "Rice",
    price: 156.25,
    change: +2.15,
    changePercent: +1.4,
    volume: "890K tons",
    high: 158.4,
    low: 152.8,
    lastUpdated: new Date().toLocaleTimeString(),
    category: "Grains",
    description: "Long grain white rice, rough basis",
  },
  {
    commodity: "Cotton",
    price: 89.45,
    change: -1.25,
    changePercent: -1.4,
    volume: "650K bales",
    high: 91.2,
    low: 88.1,
    lastUpdated: new Date().toLocaleTimeString(),
    category: "Fiber",
    description: "Cotton #2, 1-1/8 inch staple, Intercontinental Exchange",
  },
  {
    commodity: "Sugar",
    price: 23.67,
    change: +0.89,
    changePercent: +3.9,
    volume: "1.1M tons",
    high: 24.1,
    low: 22.8,
    lastUpdated: new Date().toLocaleTimeString(),
    category: "Soft Commodities",
    description: "Raw sugar #11, Intercontinental Exchange",
  },
]

const marketNews: MarketNews[] = [
  {
    id: 1,
    title: "Corn Prices Surge on Weather Concerns",
    summary: "Drought conditions in major growing regions push corn futures to 3-month highs as supply concerns mount.",
    timestamp: "2 hours ago",
    impact: "high",
    category: "Weather",
  },
  {
    id: 2,
    title: "Global Wheat Demand Shows Signs of Recovery",
    summary: "International buyers increase wheat purchases as global food security concerns drive demand higher.",
    timestamp: "4 hours ago",
    impact: "medium",
    category: "Trade",
  },
  {
    id: 3,
    title: "Soybean Export Sales Beat Expectations",
    summary: "Weekly export sales report shows strong demand from Asian markets, supporting price momentum.",
    timestamp: "6 hours ago",
    impact: "medium",
    category: "Exports",
  },
  {
    id: 4,
    title: "Federal Reserve Policy Impact on Agriculture",
    summary: "Interest rate decisions affecting farm financing and commodity investment flows.",
    timestamp: "1 day ago",
    impact: "low",
    category: "Policy",
  },
]

const marketTrends = [
  {
    period: "1 Week",
    corn: +8.2,
    wheat: -2.1,
    soybeans: +12.4,
    rice: +3.7,
  },
  {
    period: "1 Month",
    corn: +15.6,
    wheat: -8.9,
    soybeans: +22.1,
    rice: +7.3,
  },
  {
    period: "3 Months",
    corn: +28.4,
    wheat: -12.3,
    soybeans: +35.7,
    rice: +11.8,
  },
  {
    period: "1 Year",
    corn: +45.2,
    wheat: -5.4,
    soybeans: +67.3,
    rice: +23.9,
  },
]

export default function MarketPage() {
  const [marketData, setMarketData] = useState<MarketData[]>(initialMarketData)
  const [activeTab, setActiveTab] = useState("prices")
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)

  const simulatePriceUpdate = () => {
    setMarketData((prevData) =>
      prevData.map((item) => {
        // Simulate small price movements
        const priceChange = (Math.random() - 0.5) * 5 // Random change between -2.5 and +2.5
        const newPrice = Math.max(0, item.price + priceChange)
        const changeFromPrevious = newPrice - item.price
        const changePercent = (changeFromPrevious / item.price) * 100

        return {
          ...item,
          price: Math.round(newPrice * 100) / 100,
          change: Math.round(changeFromPrevious * 100) / 100,
          changePercent: Math.round(changePercent * 100) / 100,
          lastUpdated: new Date().toLocaleTimeString(),
        }
      }),
    )
  }

  useEffect(() => {
    const interval = setInterval(() => {
      simulatePriceUpdate()
      setLastRefresh(new Date())
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))
    simulatePriceUpdate()
    setLastRefresh(new Date())
    setIsRefreshing(false)
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTrendColor = (value: number) => {
    return value > 0 ? "text-green-600" : value < 0 ? "text-red-600" : "text-gray-600"
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Market Information</h1>
            <p className="text-muted-foreground text-lg">
              Live commodity prices, market trends, and trading opportunities
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-muted-foreground">Last updated: {lastRefresh.toLocaleTimeString()}</div>
            <Button variant="outline" onClick={handleRefresh} disabled={isRefreshing}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="prices">Live Prices</TabsTrigger>
          <TabsTrigger value="trends">Market Trends</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="news">Market News</TabsTrigger>
        </TabsList>

        <TabsContent value="prices" className="space-y-6">
          <Alert>
            <Clock className="h-4 w-4" />
            <AlertDescription>
              Prices update automatically every 30 seconds. Data simulated for demonstration purposes.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {marketData.map((item, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{item.commodity}</CardTitle>
                    <Badge variant="outline">{item.category}</Badge>
                  </div>
                  <CardDescription className="text-xs">{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-2xl font-bold flex items-center">
                        <DollarSign className="h-5 w-5 mr-1" />
                        {item.price}
                      </div>
                      <div className="text-xs text-muted-foreground">{item.lastUpdated}</div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {item.change > 0 ? (
                        <TrendingUp className="h-4 w-4 text-green-600" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-600" />
                      )}
                      <span className={`text-sm font-medium ${item.change > 0 ? "text-green-600" : "text-red-600"}`}>
                        {item.change > 0 ? "+" : ""}
                        {item.change} ({item.changePercent > 0 ? "+" : ""}
                        {item.changePercent}%)
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Volume:</span>
                        <div className="font-medium">{item.volume}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Range:</span>
                        <div className="font-medium text-xs">
                          H: ${item.high} L: ${item.low}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5" />
                <span>Price Performance Trends</span>
              </CardTitle>
              <CardDescription>Percentage change over different time periods</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {marketTrends.map((trend, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold">{trend.period}</h4>
                      <Badge variant="outline">Performance</Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground">Corn</div>
                        <div className={`text-lg font-bold ${getTrendColor(trend.corn)}`}>
                          {trend.corn > 0 ? "+" : ""}
                          {trend.corn}%
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground">Wheat</div>
                        <div className={`text-lg font-bold ${getTrendColor(trend.wheat)}`}>
                          {trend.wheat > 0 ? "+" : ""}
                          {trend.wheat}%
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground">Soybeans</div>
                        <div className={`text-lg font-bold ${getTrendColor(trend.soybeans)}`}>
                          {trend.soybeans > 0 ? "+" : ""}
                          {trend.soybeans}%
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground">Rice</div>
                        <div className={`text-lg font-bold ${getTrendColor(trend.rice)}`}>
                          {trend.rice > 0 ? "+" : ""}
                          {trend.rice}%
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Leaders</CardTitle>
                <CardDescription>Best performing commodities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {marketData
                    .filter((item) => item.changePercent > 0)
                    .sort((a, b) => b.changePercent - a.changePercent)
                    .slice(0, 3)
                    .map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-green-50 rounded">
                        <span className="font-medium">{item.commodity}</span>
                        <span className="text-green-600 font-bold">+{item.changePercent}%</span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Market Laggards</CardTitle>
                <CardDescription>Underperforming commodities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {marketData
                    .filter((item) => item.changePercent < 0)
                    .sort((a, b) => a.changePercent - b.changePercent)
                    .slice(0, 3)
                    .map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-red-50 rounded">
                        <span className="font-medium">{item.commodity}</span>
                        <span className="text-red-600 font-bold">{item.changePercent}%</span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Analysis</CardTitle>
                <CardDescription>Current market conditions and outlook</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Overall Market Sentiment</h4>
                  <Badge className="bg-yellow-100 text-yellow-800 mb-2">Mixed</Badge>
                  <p className="text-sm text-muted-foreground">
                    Agricultural markets showing mixed signals with grains experiencing volatility due to weather
                    concerns while soft commodities remain relatively stable.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Key Drivers</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Weather patterns affecting crop yields</li>
                    <li>• Global supply chain disruptions</li>
                    <li>• Currency fluctuations impacting exports</li>
                    <li>• Energy costs affecting production</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Trading Opportunities</CardTitle>
                <CardDescription>Potential market opportunities</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Corn Futures</span>
                    <Badge className="bg-green-100 text-green-800">Bullish</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Strong technical setup with weather concerns supporting prices
                  </p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Wheat Futures</span>
                    <Badge className="bg-red-100 text-red-800">Bearish</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Oversupply concerns weighing on prices despite export demand
                  </p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Soybean Complex</span>
                    <Badge className="bg-blue-100 text-blue-800">Neutral</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Waiting for clearer direction from South American harvest
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Economic Indicators</CardTitle>
              <CardDescription>Key metrics affecting agricultural markets</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">2.1%</div>
                  <div className="text-sm text-muted-foreground">USD Strength Index</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">$85.40</div>
                  <div className="text-sm text-muted-foreground">Crude Oil ($/barrel)</div>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">5.25%</div>
                  <div className="text-sm text-muted-foreground">Fed Funds Rate</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">3.2%</div>
                  <div className="text-sm text-muted-foreground">Inflation Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="news" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Globe className="h-5 w-5" />
                <span>Latest Market News</span>
              </CardTitle>
              <CardDescription>Breaking news and updates affecting agricultural markets</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {marketNews.map((news) => (
                  <div key={news.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-lg">{news.title}</h4>
                      <div className="flex items-center space-x-2">
                        <Badge className={getImpactColor(news.impact)}>{news.impact} impact</Badge>
                        <Badge variant="outline">{news.category}</Badge>
                      </div>
                    </div>
                    <p className="text-muted-foreground mb-3">{news.summary}</p>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{news.timestamp}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Market Alerts</CardTitle>
              <CardDescription>Important notifications and warnings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Weather Alert:</strong> Drought conditions expected to continue in major corn-producing
                    regions. Monitor crop condition reports closely.
                  </AlertDescription>
                </Alert>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Trade Update:</strong> New export agreements may impact soybean prices. USDA export sales
                    report due Thursday.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
