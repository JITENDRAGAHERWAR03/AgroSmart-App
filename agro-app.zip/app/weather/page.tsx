"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Cloud,
  Sun,
  CloudRain,
  Thermometer,
  Droplets,
  Wind,
  Eye,
  Gauge,
  MapPin,
  Calendar,
  TrendingUp,
  AlertTriangle,
  Umbrella,
  Sprout,
  Clock,
  Loader2,
} from "lucide-react"
import { fetchWeatherData } from "@/app/actions/weather"

interface WeatherData {
  current: {
    location: string
    temperature: number
    condition: string
    humidity: number
    windSpeed: number
    windDirection: string
    pressure: number
    visibility: number
    uvIndex: number
    feelsLike: number
  }
  forecast: Array<{
    day: string
    date: string
    high: number
    low: number
    condition: string
    precipitation: number
    icon: string
  }>
  alerts: Array<{
    type: string
    title: string
    description: string
    priority: string
  }>
  agricultural: {
    soilMoisture: string
    growingDegreeDay: number
    evapotranspiration: number
    frostRisk: string
    sprayConditions: string
    harvestConditions: string
  }
}

const getWeatherIcon = (condition: string) => {
  switch (condition.toLowerCase()) {
    case "sunny":
    case "clear":
      return <Sun className="h-8 w-8 text-yellow-500" />
    case "partly cloudy":
    case "partly-cloudy":
      return <Cloud className="h-8 w-8 text-gray-500" />
    case "cloudy":
    case "overcast":
      return <Cloud className="h-8 w-8 text-gray-600" />
    case "light rain":
    case "rain":
    case "showers":
      return <CloudRain className="h-8 w-8 text-blue-500" />
    default:
      return <Sun className="h-8 w-8 text-yellow-500" />
  }
}

export default function WeatherPage() {
  const [location, setLocation] = useState("Iowa, USA")
  const [activeTab, setActiveTab] = useState("current")
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const loadWeatherData = async (locationQuery: string) => {
    setLoading(true)
    setError(null)

    try {
      const data = await fetchWeatherData(locationQuery)
      setWeatherData(data)
    } catch (err) {
      console.error("Weather fetch error:", err)
      setError(err instanceof Error ? err.message : "Failed to fetch weather data")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadWeatherData(location)
  }, [])

  const handleLocationUpdate = () => {
    if (location.trim()) {
      loadWeatherData(location.trim())
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Loading weather data...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!weatherData) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center">
          <p className="text-muted-foreground">Failed to load weather data</p>
          <Button onClick={() => loadWeatherData(location)} className="mt-4">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Weather Knowledge Center</h1>
        <p className="text-muted-foreground text-lg">
          Real-time weather data and agricultural insights for informed farming decisions
        </p>
      </div>

      {/* Location Search */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Enter your farm location..."
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleLocationUpdate()}
                  className="pl-10"
                />
              </div>
            </div>
            <Button onClick={handleLocationUpdate} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Update Location
            </Button>
          </div>
          {error && (
            <Alert className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Weather Alerts */}
      {weatherData.alerts.length > 0 && (
        <div className="mb-6 space-y-3">
          {weatherData.alerts.map((alert, index) => (
            <Alert key={index} className={alert.priority === "high" ? "border-orange-500" : ""}>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>{alert.title}:</strong> {alert.description}
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="current">Current</TabsTrigger>
          <TabsTrigger value="forecast">Forecast</TabsTrigger>
          <TabsTrigger value="agricultural">Agricultural</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="current" className="space-y-6">
          {/* Current Weather Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Current Conditions</span>
                <Badge variant="outline" className="flex items-center space-x-1">
                  <Clock className="h-3 w-3" />
                  <span>Live Data</span>
                </Badge>
              </CardTitle>
              <CardDescription>{weatherData.current.location}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  {getWeatherIcon(weatherData.current.condition)}
                  <div>
                    <div className="text-4xl font-bold">{weatherData.current.temperature}°C</div>
                    <div className="text-muted-foreground">{weatherData.current.condition}</div>
                    <div className="text-sm text-muted-foreground">Feels like {weatherData.current.feelsLike}°C</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center space-x-3">
                  <Droplets className="h-5 w-5 text-blue-500" />
                  <div>
                    <div className="text-sm text-muted-foreground">Humidity</div>
                    <div className="font-semibold">{weatherData.current.humidity}%</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Wind className="h-5 w-5 text-gray-500" />
                  <div>
                    <div className="text-sm text-muted-foreground">Wind</div>
                    <div className="font-semibold">
                      {weatherData.current.windSpeed} km/h {weatherData.current.windDirection}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Gauge className="h-5 w-5 text-purple-500" />
                  <div>
                    <div className="text-sm text-muted-foreground">Pressure</div>
                    <div className="font-semibold">{weatherData.current.pressure} hPa</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Eye className="h-5 w-5 text-green-500" />
                  <div>
                    <div className="text-sm text-muted-foreground">Visibility</div>
                    <div className="font-semibold">{weatherData.current.visibility} km</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* UV Index */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Sun className="h-5 w-5 text-yellow-500" />
                <span>UV Index</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="text-3xl font-bold text-orange-500">{weatherData.current.uvIndex}</div>
                <div>
                  <div className="font-semibold">High</div>
                  <div className="text-sm text-muted-foreground">Protection recommended for outdoor work</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>5-Day Forecast</CardTitle>
              <CardDescription>Extended weather outlook for your farming operations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {weatherData.forecast.map((day, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="text-center min-w-[80px]">
                        <div className="font-semibold">{day.day}</div>
                        <div className="text-sm text-muted-foreground">{day.date}</div>
                      </div>
                      {getWeatherIcon(day.icon)}
                      <div>
                        <div className="font-medium">{day.condition}</div>
                        <div className="text-sm text-muted-foreground flex items-center space-x-1">
                          <Umbrella className="h-3 w-3" />
                          <span>{day.precipitation}%</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">
                        {day.high}° / {day.low}°
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="agricultural" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Droplets className="h-5 w-5 text-blue-500" />
                  <span>Soil Moisture</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{weatherData.agricultural.soilMoisture}</div>
                <p className="text-sm text-muted-foreground">
                  Current soil moisture levels based on humidity and recent precipitation
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Thermometer className="h-5 w-5 text-red-500" />
                  <span>Growing Degree Days</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{weatherData.agricultural.growingDegreeDay}</div>
                <p className="text-sm text-muted-foreground">Accumulated heat units for crop development</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <span>Evapotranspiration</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {weatherData.agricultural.evapotranspiration} mm
                </div>
                <p className="text-sm text-muted-foreground">Daily water loss from soil and plants</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-orange-500" />
                  <span>Frost Risk</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold ${
                    weatherData.agricultural.frostRisk === "Low"
                      ? "text-green-600"
                      : weatherData.agricultural.frostRisk === "Medium"
                        ? "text-yellow-600"
                        : "text-red-600"
                  }`}
                >
                  {weatherData.agricultural.frostRisk}
                </div>
                <p className="text-sm text-muted-foreground">Risk of frost damage to sensitive crops</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Sprout className="h-5 w-5 text-purple-500" />
                  <span>Spray Conditions</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold ${
                    weatherData.agricultural.sprayConditions === "Good"
                      ? "text-green-600"
                      : weatherData.agricultural.sprayConditions === "Fair"
                        ? "text-yellow-600"
                        : "text-red-600"
                  }`}
                >
                  {weatherData.agricultural.sprayConditions}
                </div>
                <p className="text-sm text-muted-foreground">Current conditions for pesticide/herbicide application</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-yellow-500" />
                  <span>Harvest Conditions</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold ${
                    weatherData.agricultural.harvestConditions === "Good" ? "text-green-600" : "text-yellow-600"
                  }`}
                >
                  {weatherData.agricultural.harvestConditions}
                </div>
                <p className="text-sm text-muted-foreground">Weather suitability for harvesting operations</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Farming Recommendations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">Current Conditions</p>
                    <p className="text-sm text-muted-foreground">
                      Temperature: {weatherData.current.temperature}°C, Humidity: {weatherData.current.humidity}%
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">Irrigation Planning</p>
                    <p className="text-sm text-muted-foreground">
                      Soil moisture is {weatherData.agricultural.soilMoisture.toLowerCase()}.
                      {weatherData.agricultural.soilMoisture === "Low"
                        ? " Consider irrigation."
                        : weatherData.agricultural.soilMoisture === "High"
                          ? " Reduce irrigation."
                          : " Monitor soil conditions."}
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">Field Operations</p>
                    <p className="text-sm text-muted-foreground">
                      Spray conditions are {weatherData.agricultural.sprayConditions.toLowerCase()}. Wind speed:{" "}
                      {weatherData.current.windSpeed} km/h
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Agricultural Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Today's Conditions</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Real-time agricultural data based on current weather conditions
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Growing Degree Days</span>
                      <Badge variant="secondary">{weatherData.agricultural.growingDegreeDay}</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Evapotranspiration</span>
                      <Badge variant="outline">{weatherData.agricultural.evapotranspiration} mm</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Frost Risk</span>
                      <Badge variant={weatherData.agricultural.frostRisk === "Low" ? "secondary" : "destructive"}>
                        {weatherData.agricultural.frostRisk}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Weather-Based Recommendations</CardTitle>
              <CardDescription>Actionable insights based on current and forecasted conditions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500">{weatherData.current.temperature}°C</div>
                  <div className="text-sm text-muted-foreground">Current Temperature</div>
                  <div className="text-xs text-muted-foreground">
                    {weatherData.current.temperature > 25
                      ? "Hot conditions"
                      : weatherData.current.temperature > 15
                        ? "Moderate conditions"
                        : "Cool conditions"}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">{weatherData.current.humidity}%</div>
                  <div className="text-sm text-muted-foreground">Humidity</div>
                  <div className="text-xs text-muted-foreground">
                    {weatherData.current.humidity > 70
                      ? "High moisture"
                      : weatherData.current.humidity > 40
                        ? "Moderate moisture"
                        : "Low moisture"}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-500">{weatherData.current.windSpeed} km/h</div>
                  <div className="text-sm text-muted-foreground">Wind Speed</div>
                  <div className="text-xs text-muted-foreground">
                    {weatherData.current.windSpeed > 20
                      ? "Windy conditions"
                      : weatherData.current.windSpeed > 10
                        ? "Moderate wind"
                        : "Calm conditions"}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
